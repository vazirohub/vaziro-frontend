import { PrismaClient, PlanVisibility } from "@prisma/client";

const prisma = new PrismaClient();

const categories = [
  ["Elderly Caregiver", "elderly-caregiver"],
  ["Fitness Trainer", "fitness-trainer"],
  ["Home Cook / Chef", "home-cook-chef"],
  ["Home Nurse", "home-nurse"],
  ["Home Tutor", "home-tutor"],
  ["Baby Caregiver / Japa", "baby-caregiver-japa-maid"],
  ["Physiotherapist", "physiotherapist"],
  ["Yoga Trainer", "yoga-trainer"],
] as const;

const plans = [
  { name: "Starter", pricePaise: 10_000, baseCredits: 10, bonusCredits: 0, visibility: PlanVisibility.STANDARD, description: "Standard visibility", sortOrder: 1 },
  { name: "Basic", pricePaise: 25_000, baseCredits: 25, bonusCredits: 2, visibility: PlanVisibility.ENHANCED, description: "Enhanced visibility", sortOrder: 2 },
  { name: "Popular", pricePaise: 50_000, baseCredits: 50, bonusCredits: 5, visibility: PlanVisibility.HIGH, description: "Higher visibility", sortOrder: 3, featured: true },
  { name: "Growth", pricePaise: 100_000, baseCredits: 100, bonusCredits: 15, visibility: PlanVisibility.HIGH_PRIORITY, description: "High-priority visibility", sortOrder: 4 },
  { name: "Pro", pricePaise: 250_000, baseCredits: 250, bonusCredits: 50, visibility: PlanVisibility.HIGHEST, description: "Highest eligible visibility", sortOrder: 5 },
] as const;

async function seed() {
  for (const [name, slug] of categories) {
    await prisma.category.upsert({
      where: { slug },
      update: { name, active: true },
      create: { name, slug },
    });
  }

  for (const plan of plans) {
    const { name, ...data } = plan;
    await prisma.professionalPlan.upsert({
      where: { name },
      update: data,
      create: { name, ...data },
    });
  }

  for (const pack of [
    { name: "Basic Boost", pricePaise: 2_900, durationDays: 1, priority: 1, description: "Increased visibility for one day.", sortOrder: 1 },
    { name: "Standard Boost", pricePaise: 5_900, durationDays: 3, priority: 2, description: "Increased visibility for three days.", sortOrder: 2 },
    { name: "Premium Boost", pricePaise: 9_900, durationDays: 7, priority: 3, description: "Increased visibility for seven days.", sortOrder: 3 },
  ]) {
    await prisma.boostPackage.upsert({ where: { name: pack.name }, update: pack, create: pack });
  }
}

seed().finally(() => prisma.$disconnect());
