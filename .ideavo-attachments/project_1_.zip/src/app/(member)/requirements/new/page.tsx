import { redirect } from "next/navigation";
import Link from "next/link";
import { RequirementForm } from "@/components/requirement-form";
import { currentSession } from "@/lib/session";

export default async function NewRequirementPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/requirements/new");
  if (session.user.role !== "CUSTOMER") redirect("/dashboard");
  return <section className="form-page"><Link className="back-link" href="/dashboard">← Your dashboard</Link><p className="member-kicker">FREE TO POST</p><h1>What kind of help do you need?</h1><p className="form-intro">A few details help relevant professionals understand what you're looking for.</p><div className="form-disclosure"><strong>Your budget is yours to set.</strong><span>Enter any valid amount. Professionals see the budget when deciding whether to send you a quotation.</span></div><RequirementForm /></section>;
}
