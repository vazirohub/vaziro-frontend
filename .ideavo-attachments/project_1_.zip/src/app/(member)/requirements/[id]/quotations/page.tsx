import { notFound, redirect } from "next/navigation";
import { CustomerQuotations } from "@/components/customer-quotations";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export default async function RequirementQuotationsPage({ params }: PageProps<"/requirements/[id]/quotations">) {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/dashboard");
  if (session.user.role !== "CUSTOMER") redirect("/dashboard");
  const { id } = await params;
  const customer = await prisma.customerProfile.findUnique({ where: { userId: session.user.id } });
  const requirement = customer ? await prisma.requirement.findFirst({ where: { id, customerId: customer.id }, select: { id: true, title: true, budgetPaise: true } }) : null;
  if (!requirement) notFound();
  return <section className="plans-page"><p className="member-kicker">YOUR REQUIREMENT</p><h1>{requirement.title}</h1><p className="form-intro">Budget {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(requirement.budgetPaise / 100)}</p><CustomerQuotations requirementId={id} /></section>;
}
