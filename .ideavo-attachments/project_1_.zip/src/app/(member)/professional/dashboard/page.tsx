import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(paise / 100);

export default async function ProfessionalDashboardPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/professional/dashboard");
  if (session.user.role !== "PROFESSIONAL") redirect("/dashboard");
  const profile = await prisma.professionalProfile.findUnique({ where: { userId: session.user.id }, include: { categories: true } });
  if (!profile) return <section className="member-empty"><h1>Set up your professional profile</h1><p>Add your service area and categories to discover relevant customer requirements.</p><Link className="button button-dark" href="/professional/profile">Complete profile</Link></section>;
  const [batches, applicationCount, activeJobs] = await Promise.all([
    prisma.creditBatch.findMany({ where: { professionalId: profile.id, status: "ACTIVE", OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] } }).catch(() => []),
    prisma.application.count({ where: { professionalId: profile.id } }).catch(() => 0),
    prisma.job.count({ where: { professionalId: profile.id, status: "ACTIVE" } }).catch(() => 0),
  ]);
  const purchased = batches.reduce((total, batch) => total + batch.remainingPurchasedCredits, 0);
  const bonus = batches.reduce((total, batch) => total + batch.remainingBonusCredits, 0);
  const nextExpiry = batches.filter((batch) => batch.expiresAt).sort((a, b) => a.expiresAt!.getTime() - b.expiresAt!.getTime())[0]?.expiresAt;
  return <>
    <div className="member-title-row"><div><p className="member-kicker">PROFESSIONAL WORKSPACE</p><h1>Welcome, {session.user.name.split(" ")[0]}</h1><p>Find the right requests and build your independent practice.</p></div><Link className="button button-dark" href="/professional/requirements">Find requirements <span aria-hidden="true">↗</span></Link></div>
    <div className="stat-grid"><article className="stat-card stat-primary"><span>Available Credits</span><strong>{purchased + bonus}</strong><small>{purchased} purchased · {bonus} bonus</small></article><article className="stat-card"><span>Applications</span><strong>{applicationCount}</strong><small>Submitted to customer requests</small></article><article className="stat-card"><span>Active jobs</span><strong>{activeJobs}</strong><small>Accepted quotations</small></article></div>
    <div className="dashboard-columns"><section className="member-section"><div className="member-section-heading"><div><h2>Credit details</h2><p>Purchased Credits are refundable if unused after 90 days. Bonus Credits are non-refundable.</p></div></div><div className="expiry-panel"><span>Next expiry</span><strong>{nextExpiry ? nextExpiry.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Kolkata" }) : "No active expiry"}</strong><span>Refundable amount</span><strong>{money(batches.filter((batch) => batch.expiresAt && batch.expiresAt <= new Date()).reduce((sum, batch) => sum + batch.remainingPurchasedCredits * 1000, 0))}</strong><Link className="text-link" href="/professional/credits">View Credit history →</Link></div></section><section className="member-section"><div className="member-section-heading"><div><h2>Grow your practice</h2><p>Choose the customer requests that fit your services and availability.</p></div></div><div className="quick-link-list"><Link href="/professional/requirements"><span>Browse relevant requirements</span><b>→</b></Link><Link href="/professional/applications"><span>Track applications & quotations</span><b>→</b></Link><Link href="/professional/plans"><span>Explore Professional Plans</span><b>→</b></Link><Link href="/professional/profile"><span>Manage your profile</span><b>→</b></Link></div></section></div>
  </>;
}
