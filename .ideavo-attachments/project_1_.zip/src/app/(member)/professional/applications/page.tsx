import { redirect } from "next/navigation";
import { ProfessionalApplications } from "@/components/professional-applications";
import { currentSession } from "@/lib/session";

export default async function ProfessionalApplicationsPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/professional/applications");
  if (session.user.role !== "PROFESSIONAL") redirect("/dashboard");
  return <ProfessionalApplications />;
}
