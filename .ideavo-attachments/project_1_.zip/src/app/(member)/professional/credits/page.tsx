import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(paise / 100);

export default async function CreditsPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/professional/credits");
  if (session.user.role !== "PROFESSIONAL") redirect("/dashboard");
  const profile = await prisma.professionalProfile.findUnique({ where: { userId: session.user.id } });
  const batches = profile ? await prisma.creditBatch.findMany({ where: { professionalId: profile.id }, orderBy: [{ createdAt: "desc" }] }).catch(() => []) : [];
  const ledger = profile ? await prisma.creditLedger.findMany({ where: { professionalId: profile.id }, include: { batch: { select: { expiresAt: true } } }, orderBy: { createdAt: "desc" }, take: 50 }).catch(() => []) : [];
  const now = new Date();
  const usable = batches.filter((batch) => batch.status === "ACTIVE" && (!batch.expiresAt || batch.expiresAt > now));
  const purchased = usable.reduce((sum, batch) => sum + batch.remainingPurchasedCredits, 0);
  const bonus = usable.reduce((sum, batch) => sum + batch.remainingBonusCredits, 0);
  const eligible = batches.filter((batch) => batch.expiresAt && batch.expiresAt <= now && !["REFUNDED", "EXPIRED_NON_REFUNDABLE"].includes(batch.status));
  const refundable = eligible.reduce((sum, batch) => sum + batch.remainingPurchasedCredits, 0);
  const nextExpiry = usable.filter((batch) => batch.expiresAt).sort((a, b) => a.expiresAt!.getTime() - b.expiresAt!.getTime())[0]?.expiresAt;
  return <section className="plans-page"><p className="member-kicker">YOUR CREDIT WALLET</p><h1>Credits & history</h1><p className="form-intro">Credits are used when you apply to customer requirements. Purchased and bonus Credits are tracked separately.</p>
    <div className="stat-grid"><article className="stat-card stat-primary"><span>Available Credits</span><strong>{purchased + bonus}</strong><small>Whole Credits only</small></article><article className="stat-card"><span>Purchased Credits</span><strong>{purchased}</strong><small>Refundable if unused after 90 days</small></article><article className="stat-card"><span>Bonus Credits</span><strong>{bonus}</strong><small>Promotional and non-refundable</small></article></div>
    <div className="wallet-summary"><div><span>Next expiry</span><strong>{nextExpiry ? nextExpiry.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Kolkata" }) : "No active expiry"}</strong></div><div><span>Refundable now</span><strong>{refundable} purchased Credits · {money(refundable * 1_000)}</strong></div></div>
    <section className="member-section"><div className="member-section-heading"><div><h2>Credit history</h2><p>Ledger entries are retained for your account history.</p></div></div>{ledger.length === 0 ? <div className="empty-inline"><p>No Credit activity yet.</p><Link href="/professional/plans">View Professional Plans →</Link></div> : <div className="ledger-table-wrap"><table className="ledger-table"><thead><tr><th>Date</th><th>Description</th><th>Type</th><th>Credits</th><th>Balance</th></tr></thead><tbody>{ledger.map((entry) => <tr key={entry.id}><td>{entry.createdAt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</td><td>{entry.reason ?? entry.type.replaceAll("_", " ")}</td><td>{entry.type.replaceAll("_", " ")}</td><td className={entry.amount < 0 ? "ledger-negative" : "ledger-positive"}>{entry.amount > 0 ? "+" : ""}{entry.amount}</td><td>{entry.balanceAfter}</td></tr>)}</tbody></table></div>}</section>
  </section>;
}
