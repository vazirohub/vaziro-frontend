import { redirect } from "next/navigation";
import { ProfessionalProfileForm } from "@/components/professional-profile-form";
import { currentSession } from "@/lib/session";

export default async function ProfessionalProfilePage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/professional/profile");
  if (session.user.role !== "PROFESSIONAL") redirect("/dashboard");
  return <section className="form-page"><p className="member-kicker">YOUR PROFESSIONAL PROFILE</p><h1>Tell customers what you do best</h1><p className="form-intro">Your profile and service area help us show you relevant customer requests.</p><ProfessionalProfileForm /></section>;
}
