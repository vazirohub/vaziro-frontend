import { redirect } from "next/navigation";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(paise / 100);

export default async function ProfessionalPlansPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/professional/plans");
  if (session.user.role !== "PROFESSIONAL") redirect("/dashboard");
  const plans = await prisma.professionalPlan.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }).catch(() => []);
  return <section className="plans-page"><p className="member-kicker">ONE PLAN. CREDITS + VISIBILITY.</p><h1>Vaziro Professional Plans</h1><p className="form-intro">Get Credits to apply to customer requirements, plus increased profile visibility.</p>
    <div className="plan-grid">{plans.map((plan) => <article className={`plan-card${plan.featured ? " plan-featured" : ""}`} key={plan.id}>{plan.featured && <span className="plan-badge">POPULAR</span>}<p className="plan-name">{plan.name}</p><strong className="plan-price">{money(plan.pricePaise)}</strong><p className="plan-credit-line">{plan.baseCredits} Base Credits</p>{plan.bonusCredits > 0 && <p className="plan-bonus">+ {plan.bonusCredits} Bonus Credits</p>}<p className="plan-total">{plan.baseCredits + plan.bonusCredits} total Credits</p><div className="plan-visibility">{plan.description}</div><button className="button button-outline plan-disabled" disabled>Checkout setup required</button></article>)}</div>
    {plans.length === 0 && <div className="inline-state">Plans are not loaded yet. Run the database migrations and seed the marketplace plans.</div>}
    <div className="plan-policy"><strong>Before you purchase</strong><p>Purchased Credits are valid for 90 days from the date they are credited. Unused purchased Credits become eligible for refund after 90 days at ₹10 per Credit. Bonus Credits are promotional and are non-refundable.</p><p>Visibility benefits improve your eligibility in relevant discovery and ranking. They do not guarantee leads, quotations, jobs or placement.</p></div>
  </section>;
}
