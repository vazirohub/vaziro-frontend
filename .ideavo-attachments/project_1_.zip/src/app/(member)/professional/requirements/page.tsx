import { redirect } from "next/navigation";
import { RequirementFeed } from "@/components/requirement-feed";
import { currentSession } from "@/lib/session";

export default async function ProfessionalRequirementsPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/professional/requirements");
  if (session.user.role !== "PROFESSIONAL") redirect("/dashboard");
  return <RequirementFeed />;
}
