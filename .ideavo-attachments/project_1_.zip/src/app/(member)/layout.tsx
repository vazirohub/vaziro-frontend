import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/session";

export default async function MemberLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/dashboard");
  return <div className="member-frame"><header className="member-header"><Link className="wordmark" href="/">vaziro<span>.</span></Link><nav aria-label="Account navigation"><Link href="/dashboard">Dashboard</Link>{session.user.role === "PROFESSIONAL" ? <><Link href="/professional/requirements">Find requirements</Link><Link href="/professional/plans">Professional plans</Link></> : session.user.role === "CUSTOMER" ? <Link href="/requirements/new">Post a requirement</Link> : <Link href="/admin">Admin</Link>}</nav><span className="member-user">{session.user.name}</span></header><main className="member-content">{children}</main></div>;
}
