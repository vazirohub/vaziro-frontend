import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/dashboard");
  if (session.user.role === "ADMIN") redirect("/admin");
  if (session.user.role === "PROFESSIONAL") redirect("/professional/dashboard");
  const profile = await prisma.customerProfile.findUnique({ where: { userId: session.user.id } }).catch(() => null);
  const requirements = profile ? await prisma.requirement.findMany({ where: { customerId: profile.id }, include: { category: { select: { name: true } }, _count: { select: { applications: true } } }, orderBy: { createdAt: "desc" }, take: 5 }).catch(() => []) : [];
  return <>
    <div className="member-title-row"><div><p className="member-kicker">YOUR HOME BASE</p><h1>Welcome, {session.user.name.split(" ")[0]}</h1><p>Keep track of the help you're looking for.</p></div><Link className="button button-dark" href="/requirements/new">Post a requirement <span aria-hidden="true">↗</span></Link></div>
    <section className="member-section"><div className="member-section-heading"><div><h2>Your requirements</h2><p>Requirements are free to post. Compare professionals when they respond.</p></div><Link className="text-link" href="/requirements/new">Post another <span aria-hidden="true">→</span></Link></div>
      {requirements.length === 0 ? <div className="member-empty"><span className="empty-mark">+</span><h3>Start with what you need</h3><p>Share your budget, location and a few details. Relevant professionals can send you a quotation.</p><Link className="button button-dark" href="/requirements/new">Create a requirement</Link></div> : <div className="requirement-list">{requirements.map((item) => <article className="requirement-row" key={item.id}><div><span className="row-category">{item.category.name}</span><h3>{item.title}</h3><p>{item.city} · {item._count.applications} {item._count.applications === 1 ? "application" : "applications"}</p><Link className="quote-link" href={`/requirements/${item.id}/quotations`}>View quotations →</Link></div><div className="requirement-meta"><strong>{new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(item.budgetPaise / 100)}</strong><span className={`status-label status-${item.status.toLowerCase()}`}>{item.status.toLowerCase()}</span></div></article>)}</div>}
    </section>
  </>;
}
