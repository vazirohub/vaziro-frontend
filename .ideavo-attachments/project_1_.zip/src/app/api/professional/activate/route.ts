import { NextResponse } from "next/server";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function POST() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role === "ADMIN") return NextResponse.json({ message: "This account cannot change roles." }, { status: 403 });

  try {
    await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: session.user.id }, data: { role: "PROFESSIONAL" } });
      await tx.professionalProfile.upsert({
        where: { userId: session.user.id },
        update: {},
        create: { userId: session.user.id },
      });
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ message: "We couldn't set up your profile. Please try again." }, { status: 503 });
  }
}
