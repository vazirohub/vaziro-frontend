import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const plans = await prisma.professionalPlan.findMany({
      where: { active: true },
      orderBy: { sortOrder: "asc" },
      select: { id: true, name: true, pricePaise: true, baseCredits: true, bonusCredits: true, visibility: true, description: true, featured: true },
    });
    return NextResponse.json({ success: true, plans });
  } catch {
    return NextResponse.json({ success: false, message: "Plans are temporarily unavailable." }, { status: 503 });
  }
}
