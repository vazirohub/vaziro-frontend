import { NextResponse } from "next/server";
import { refundableAmountPaise } from "@/lib/credits";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ success: false, message: "Sign in to view your Credits.", code: "UNAUTHORIZED" }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ success: false, message: "Professional access is required.", code: "FORBIDDEN" }, { status: 403 });
  try {
    const profile = await prisma.professionalProfile.findUnique({ where: { userId: session.user.id } });
    if (!profile) return NextResponse.json({ success: true, availableCredits: 0, purchasedCredits: 0, bonusCredits: 0, refundableCredits: 0, refundableAmountPaise: 0, batches: [], ledger: [] });
    const now = new Date();
    const [batches, ledger] = await Promise.all([
      prisma.creditBatch.findMany({ where: { professionalId: profile.id }, orderBy: [{ expiresAt: "asc" }, { grantedAt: "asc" }] }),
      prisma.creditLedger.findMany({ where: { professionalId: profile.id }, orderBy: { createdAt: "desc" }, take: 50 }),
    ]);
    const validBatches = batches.filter((batch) => batch.status === "ACTIVE" && (!batch.expiresAt || batch.expiresAt > now));
    const refundableBatches = batches.filter((batch) => batch.expiresAt && batch.expiresAt <= now && !["REFUNDED", "EXPIRED_NON_REFUNDABLE"].includes(batch.status));
    const purchasedCredits = validBatches.reduce((sum, batch) => sum + batch.remainingPurchasedCredits, 0);
    const bonusCredits = validBatches.reduce((sum, batch) => sum + batch.remainingBonusCredits, 0);
    const refundableCredits = refundableBatches.reduce((sum, batch) => sum + batch.remainingPurchasedCredits, 0);
    const nextExpiry = validBatches.filter((batch) => batch.expiresAt).sort((a, b) => a.expiresAt!.getTime() - b.expiresAt!.getTime())[0]?.expiresAt ?? null;
    return NextResponse.json({
      success: true,
      availableCredits: purchasedCredits + bonusCredits,
      purchasedCredits,
      bonusCredits,
      expiringCredits: nextExpiry ? validBatches.filter((batch) => batch.expiresAt?.getTime() === nextExpiry.getTime()).reduce((sum, batch) => sum + batch.remainingPurchasedCredits + batch.remainingBonusCredits, 0) : 0,
      nextExpiry,
      refundableCredits,
      refundableAmountPaise: refundableAmountPaise(refundableCredits),
      batches,
      ledger,
    });
  } catch {
    return NextResponse.json({ success: false, message: "We couldn't load your Credit history. Refresh and try again." }, { status: 503 });
  }
}
