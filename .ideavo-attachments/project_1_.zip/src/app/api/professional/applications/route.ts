import { NextResponse } from "next/server";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to view your applications." }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ message: "Professional access is required." }, { status: 403 });
  try {
    const profile = await prisma.professionalProfile.findUnique({ where: { userId: session.user.id } });
    if (!profile) return NextResponse.json({ applications: [] });
    const applications = await prisma.application.findMany({
      where: { professionalId: profile.id },
      include: { requirement: { include: { category: { select: { name: true } }, subcategory: { select: { name: true } } } }, quotation: true },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ applications });
  } catch {
    return NextResponse.json({ message: "We couldn't load your applications. Refresh and try again." }, { status: 503 });
  }
}
