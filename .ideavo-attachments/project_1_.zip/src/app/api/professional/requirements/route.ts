import { NextResponse } from "next/server";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ success: false, message: "Sign in to find requirements.", code: "UNAUTHORIZED" }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ success: false, message: "Professional access is required.", code: "FORBIDDEN" }, { status: 403 });
  try {
    const profile = await prisma.professionalProfile.findUnique({ where: { userId: session.user.id }, include: { categories: { select: { categoryId: true, subcategoryId: true } } } });
    if (!profile) return NextResponse.json({ success: true, requirements: [] });
    const url = new URL(request.url);
    const requestedCity = url.searchParams.get("city")?.trim();
    const city = requestedCity || profile.city;
    const categoryIds = [...new Set(profile.categories.map((item) => item.categoryId))];
    if (!categoryIds.length || !city) return NextResponse.json({ success: true, requirements: [], needsProfile: true });
    const requirements = await prisma.requirement.findMany({
      where: {
        status: "OPEN",
        OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
        categoryId: { in: categoryIds },
        city: { equals: city },
        NOT: { applications: { some: { professionalId: profile.id } } },
      },
      include: {
        category: { select: { name: true } },
        subcategory: { select: { name: true } },
        boosts: { where: { status: "ACTIVE", startsAt: { lte: new Date() }, expiresAt: { gt: new Date() } }, include: { package: { select: { priority: true } } } },
      },
      orderBy: [{ createdAt: "desc" }],
      take: 100,
    });
    const ordered = requirements.sort((a, b) => {
      const priorityA = Math.max(0, ...a.boosts.map((boost) => boost.package.priority));
      const priorityB = Math.max(0, ...b.boosts.map((boost) => boost.package.priority));
      return priorityB - priorityA || b.createdAt.getTime() - a.createdAt.getTime();
    });
    return NextResponse.json({ success: true, requirements: ordered });
  } catch {
    return NextResponse.json({ success: false, message: "We couldn't load the requirement feed. Refresh and try again." }, { status: 503 });
  }
}
