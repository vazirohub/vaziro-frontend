import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const inputSchema = z.object({
  headline: z.string().trim().min(5).max(120),
  description: z.string().trim().min(40).max(3000),
  experienceYears: z.number().int().min(0).max(70),
  city: z.string().trim().min(2).max(100),
  skills: z.array(z.string().trim().min(1).max(50)).max(20),
  categoryIds: z.array(z.string().min(1)).min(1).max(20),
});

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to manage your profile." }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ message: "Professional access is required." }, { status: 403 });
  try {
    const [profile, categories] = await Promise.all([
      prisma.professionalProfile.findUnique({ where: { userId: session.user.id }, include: { categories: { select: { categoryId: true } } } }),
      prisma.category.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" }, select: { id: true, name: true } }),
    ]);
    return NextResponse.json({ profile, categories });
  } catch {
    return NextResponse.json({ message: "Profile settings are temporarily unavailable." }, { status: 503 });
  }
}

export async function PATCH(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to manage your profile." }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ message: "Professional access is required." }, { status: 403 });
  const parsed = inputSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the profile details and try again.", errors: parsed.error.flatten().fieldErrors }, { status: 400 });
  try {
    const activeCategories = await prisma.category.findMany({ where: { id: { in: parsed.data.categoryIds }, active: true }, select: { id: true } });
    if (activeCategories.length !== new Set(parsed.data.categoryIds).size) return NextResponse.json({ message: "Choose active service categories." }, { status: 400 });
    await prisma.$transaction(async (tx) => {
      const profile = await tx.professionalProfile.upsert({
        where: { userId: session.user.id },
        update: { headline: parsed.data.headline, description: parsed.data.description, experienceYears: parsed.data.experienceYears, city: parsed.data.city, serviceAreas: [parsed.data.city], skills: parsed.data.skills },
        create: { userId: session.user.id, headline: parsed.data.headline, description: parsed.data.description, experienceYears: parsed.data.experienceYears, city: parsed.data.city, serviceAreas: [parsed.data.city], skills: parsed.data.skills },
      });
      await tx.professionalCategory.deleteMany({ where: { professionalId: profile.id } });
      await tx.professionalCategory.createMany({ data: parsed.data.categoryIds.map((categoryId) => ({ professionalId: profile.id, categoryId })) });
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ message: "We couldn't save your profile. Please try again." }, { status: 503 });
  }
}
