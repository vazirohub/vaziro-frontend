import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const input = z.object({ categoryId: z.string().min(1), name: z.string().trim().min(2).max(80), slug: z.string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100), active: z.boolean().optional(), sortOrder: z.number().int().min(0).optional() });

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = input.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the subcategory details and try again." }, { status: 400 });
  try {
    const subcategory = await prisma.subcategory.create({ data: parsed.data });
    await prisma.auditLog.create({ data: { actorId: session.user.id, action: "SUBCATEGORY_CREATED", entity: "Subcategory", entityId: subcategory.id, after: parsed.data } });
    return NextResponse.json({ subcategory }, { status: 201 });
  } catch {
    return NextResponse.json({ message: "Choose an active category and a unique subcategory slug." }, { status: 409 });
  }
}
