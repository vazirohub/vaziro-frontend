import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const packageInput = z.object({ name: z.string().trim().min(2).max(80), pricePaise: z.number().int().positive(), durationDays: z.number().int().positive().max(365), priority: z.number().int().min(0).max(100), description: z.string().max(500).optional(), active: z.boolean(), sortOrder: z.number().int().min(0) });

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = packageInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the boost package details and try again." }, { status: 400 });
  try {
    const boostPackage = await prisma.boostPackage.create({ data: parsed.data });
    await prisma.auditLog.create({ data: { actorId: session.user.id, action: "BOOST_PACKAGE_CREATED", entity: "BoostPackage", entityId: boostPackage.id, after: parsed.data } });
    return NextResponse.json({ boostPackage }, { status: 201 });
  } catch {
    return NextResponse.json({ message: "We couldn't create that package. Check that its name is unique." }, { status: 409 });
  }
}
