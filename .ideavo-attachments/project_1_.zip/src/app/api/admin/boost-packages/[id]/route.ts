import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const input = z.object({ name: z.string().trim().min(2).max(80), pricePaise: z.number().int().positive(), durationDays: z.number().int().positive().max(365), priority: z.number().int().min(0).max(100), description: z.string().max(500).optional().nullable(), active: z.boolean(), sortOrder: z.number().int().min(0) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = input.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the boost package details and try again." }, { status: 400 });
  const { id } = await params;
  try {
    const before = await prisma.boostPackage.findUnique({ where: { id } });
    if (!before) return NextResponse.json({ message: "Boost package not found." }, { status: 404 });
    const boostPackage = await prisma.$transaction(async (tx) => {
      const updated = await tx.boostPackage.update({ where: { id }, data: parsed.data });
      await tx.auditLog.create({ data: { actorId: session.user.id, action: "BOOST_PACKAGE_UPDATED", entity: "BoostPackage", entityId: id, before, after: parsed.data } });
      return updated;
    });
    return NextResponse.json({ boostPackage });
  } catch {
    return NextResponse.json({ message: "We couldn't update that package." }, { status: 409 });
  }
}
