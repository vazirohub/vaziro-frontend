import { NextResponse } from "next/server";
import { PlanVisibility } from "@prisma/client";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const input = z.object({ name: z.string().trim().min(2).max(60), pricePaise: z.number().int().positive(), baseCredits: z.number().int().nonnegative(), bonusCredits: z.number().int().nonnegative(), visibility: z.nativeEnum(PlanVisibility), description: z.string().max(500).optional().nullable(), active: z.boolean(), featured: z.boolean(), sortOrder: z.number().int().min(0) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = input.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the plan details and try again." }, { status: 400 });
  const { id } = await params;
  try {
    const before = await prisma.professionalPlan.findUnique({ where: { id } });
    if (!before) return NextResponse.json({ message: "Plan not found." }, { status: 404 });
    const plan = await prisma.$transaction(async (tx) => {
      const updated = await tx.professionalPlan.update({ where: { id }, data: parsed.data });
      await tx.auditLog.create({ data: { actorId: session.user.id, action: "PLAN_UPDATED", entity: "ProfessionalPlan", entityId: id, before, after: parsed.data } });
      return updated;
    });
    return NextResponse.json({ plan });
  } catch {
    return NextResponse.json({ message: "We couldn't update that plan. Check that its name is unique." }, { status: 409 });
  }
}
