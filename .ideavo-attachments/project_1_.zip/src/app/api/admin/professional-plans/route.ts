import { NextResponse } from "next/server";
import { PlanVisibility } from "@prisma/client";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const planInput = z.object({ name: z.string().trim().min(2).max(60), pricePaise: z.number().int().positive(), baseCredits: z.number().int().nonnegative(), bonusCredits: z.number().int().nonnegative(), visibility: z.nativeEnum(PlanVisibility), description: z.string().max(500).optional(), active: z.boolean(), featured: z.boolean(), sortOrder: z.number().int().min(0) });

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = planInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the plan details and try again." }, { status: 400 });
  try {
    const plan = await prisma.professionalPlan.create({ data: parsed.data });
    await prisma.auditLog.create({ data: { actorId: session.user.id, action: "PLAN_CREATED", entity: "ProfessionalPlan", entityId: plan.id, after: parsed.data } });
    return NextResponse.json({ plan }, { status: 201 });
  } catch {
    return NextResponse.json({ message: "We couldn't create that plan. Check that its name is unique." }, { status: 409 });
  }
}
