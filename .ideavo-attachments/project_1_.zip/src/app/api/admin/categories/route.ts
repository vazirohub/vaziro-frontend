import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const categoryInput = z.object({ name: z.string().trim().min(2).max(80), slug: z.string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100), description: z.string().max(1000).optional(), active: z.boolean().optional(), sortOrder: z.number().int().min(0).optional() });

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = categoryInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Enter a category name and URL-safe slug." }, { status: 400 });
  try {
    const category = await prisma.category.create({ data: parsed.data });
    await prisma.auditLog.create({ data: { actorId: session.user.id, action: "CATEGORY_CREATED", entity: "Category", entityId: category.id, after: parsed.data } });
    return NextResponse.json({ category }, { status: 201 });
  } catch {
    return NextResponse.json({ message: "Category name or slug is already in use." }, { status: 409 });
  }
}
