import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const input = z.object({ name: z.string().trim().min(2).max(80), slug: z.string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100), description: z.string().max(1000).optional().nullable(), active: z.boolean(), sortOrder: z.number().int().min(0) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const parsed = input.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check the category details and try again." }, { status: 400 });
  const { id } = await params;
  try {
    const before = await prisma.category.findUnique({ where: { id } });
    if (!before) return NextResponse.json({ message: "Category not found." }, { status: 404 });
    const category = await prisma.$transaction(async (tx) => {
      const updated = await tx.category.update({ where: { id }, data: parsed.data });
      await tx.auditLog.create({ data: { actorId: session.user.id, action: "CATEGORY_UPDATED", entity: "Category", entityId: id, before, after: parsed.data } });
      return updated;
    });
    return NextResponse.json({ category });
  } catch {
    return NextResponse.json({ message: "We couldn't update this category. Check that its slug is unique." }, { status: 409 });
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  const { id } = await params;
  try {
    const category = await prisma.category.findUnique({ where: { id }, include: { _count: { select: { requirements: true, professionals: true } } } });
    if (!category) return NextResponse.json({ message: "Category not found." }, { status: 404 });
    if (category._count.requirements > 0 || category._count.professionals > 0) return NextResponse.json({ message: "This category has marketplace history. Disable it instead of deleting it." }, { status: 409 });
    await prisma.$transaction(async (tx) => {
      await tx.category.delete({ where: { id } });
      await tx.auditLog.create({ data: { actorId: session.user.id, action: "CATEGORY_DELETED", entity: "Category", entityId: id, before: { name: category.name, slug: category.slug } } });
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ message: "We couldn't delete this category." }, { status: 409 });
  }
}
