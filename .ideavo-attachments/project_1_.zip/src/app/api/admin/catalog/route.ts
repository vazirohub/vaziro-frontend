import { NextResponse } from "next/server";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to continue." }, { status: 401 });
  if (session.user.role !== "ADMIN") return NextResponse.json({ message: "Admin access is required." }, { status: 403 });
  try {
    const [categories, plans, boostPackages] = await Promise.all([
      prisma.category.findMany({ include: { subcategories: { orderBy: { sortOrder: "asc" } } }, orderBy: { sortOrder: "asc" } }),
      prisma.professionalPlan.findMany({ orderBy: { sortOrder: "asc" } }),
      prisma.boostPackage.findMany({ orderBy: { sortOrder: "asc" } }),
    ]);
    return NextResponse.json({ categories, plans, boostPackages });
  } catch {
    return NextResponse.json({ message: "Catalog settings are temporarily unavailable." }, { status: 503 });
  }
}
