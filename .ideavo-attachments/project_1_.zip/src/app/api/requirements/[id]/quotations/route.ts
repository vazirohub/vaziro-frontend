import { NextResponse } from "next/server";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to view quotations." }, { status: 401 });
  if (session.user.role !== "CUSTOMER") return NextResponse.json({ message: "Customer access is required." }, { status: 403 });
  const { id } = await params;
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: session.user.id } });
    const requirement = customer ? await prisma.requirement.findFirst({ where: { id, customerId: customer.id }, select: { id: true } }) : null;
    if (!requirement) return NextResponse.json({ message: "Requirement not found." }, { status: 404 });
    const quotations = await prisma.quotation.findMany({
      where: { requirementId: id },
      include: { professional: { include: { user: { select: { name: true, image: true } }, categories: { include: { category: { select: { name: true } } } }, reviews: { select: { rating: true } } } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ quotations });
  } catch {
    return NextResponse.json({ message: "We couldn't load quotations. Refresh and try again." }, { status: 503 });
  }
}
