import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { creditsForBudgetPaise } from "@/lib/credits";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ success: false, message: "Sign in to apply.", code: "UNAUTHORIZED" }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ success: false, message: "Professional access is required.", code: "FORBIDDEN" }, { status: 403 });
  const { id } = await params;

  try {
    const result = await prisma.$transaction(async (tx) => {
      const profile = await tx.professionalProfile.findUnique({ where: { userId: session.user.id } });
      if (!profile) throw new Error("PROFILE_REQUIRED");

      const requirement = await tx.requirement.findUnique({ where: { id } });
      if (!requirement || requirement.status !== "OPEN" || (requirement.expiresAt && requirement.expiresAt <= new Date())) throw new Error("REQUIREMENT_CLOSED");
      const matchesCategory = await tx.professionalCategory.findFirst({
        where: { professionalId: profile.id, categoryId: requirement.categoryId, OR: [{ subcategoryId: requirement.subcategoryId }, { subcategoryId: null }] },
      });
      if (!matchesCategory || profile.city?.toLowerCase() !== requirement.city.toLowerCase()) throw new Error("NOT_ELIGIBLE");

      const credits = creditsForBudgetPaise(requirement.budgetPaise);
      await tx.$queryRaw(Prisma.sql`SELECT id FROM CreditBatch WHERE professionalId = ${profile.id} FOR UPDATE`);
      const now = new Date();
      const batches = await tx.creditBatch.findMany({
        where: {
          professionalId: profile.id,
          status: "ACTIVE",
          OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
        },
      });
      const eligibleBatches = batches
        .filter((batch) => batch.remainingPurchasedCredits + batch.remainingBonusCredits > 0)
        .sort((a, b) => (a.expiresAt?.getTime() ?? Number.MAX_SAFE_INTEGER) - (b.expiresAt?.getTime() ?? Number.MAX_SAFE_INTEGER) || a.grantedAt.getTime() - b.grantedAt.getTime());
      const available = eligibleBatches.reduce((sum, batch) => sum + batch.remainingPurchasedCredits + batch.remainingBonusCredits, 0);
      if (available < credits) throw new Error(`INSUFFICIENT_CREDITS:${credits}:${available}`);
      const existing = await tx.application.findUnique({ where: { professionalId_requirementId: { professionalId: profile.id, requirementId: id } }, select: { id: true } });
      if (existing) throw new Error("ALREADY_APPLIED");

      const application = await tx.application.create({
        data: {
          professionalId: profile.id,
          requirementId: requirement.id,
          customerBudgetPaise: requirement.budgetPaise,
          creditPercentageAtApplication: 10,
          creditValuePaise: 1_000,
          creditsCharged: credits,
        },
      });

      let remaining = credits;
      let balanceAfter = available;
      for (const batch of eligibleBatches) {
        if (remaining === 0) break;
        const bonusUsed = Math.min(batch.remainingBonusCredits, remaining);
        const purchasedUsed = Math.min(batch.remainingPurchasedCredits, remaining - bonusUsed);
        const used = bonusUsed + purchasedUsed;
        if (!used) continue;
        await tx.creditBatch.update({
          where: { id: batch.id },
          data: { remainingBonusCredits: { decrement: bonusUsed }, remainingPurchasedCredits: { decrement: purchasedUsed } },
        });
        await tx.creditAllocation.create({ data: { applicationId: application.id, batchId: batch.id, purchasedUsed, bonusUsed } });
        balanceAfter -= used;
        await tx.creditLedger.create({
          data: {
            professionalId: profile.id,
            batchId: batch.id,
            type: "APPLICATION_DEBIT",
            amount: -used,
            balanceBefore: balanceAfter + used,
            balanceAfter,
            referenceId: application.id,
            reason: `Applied to requirement ${requirement.id}`,
          },
        });
        remaining -= used;
      }

      const customer = await tx.customerProfile.findUnique({ where: { id: requirement.customerId }, select: { userId: true } });
      if (customer) await tx.notification.create({ data: { userId: customer.userId, type: "APPLICATION_SUBMITTED", title: "A professional is interested", body: "A professional applied to your requirement." } });
      return { application, creditsCharged: credits, balanceAfter };
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    return NextResponse.json({ success: true, ...result }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "PROFILE_REQUIRED") return NextResponse.json({ success: false, message: "Complete your professional profile before applying.", code: "PROFILE_REQUIRED" }, { status: 409 });
    if (message === "REQUIREMENT_CLOSED") return NextResponse.json({ success: false, message: "This requirement is no longer accepting applications.", code: "REQUIREMENT_CLOSED" }, { status: 409 });
    if (message === "NOT_ELIGIBLE") return NextResponse.json({ success: false, message: "This requirement does not match your category and service area.", code: "NOT_ELIGIBLE" }, { status: 403 });
    if (message === "ALREADY_APPLIED" || (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002")) return NextResponse.json({ success: false, message: "You have already applied to this requirement.", code: "DUPLICATE_APPLICATION" }, { status: 409 });
    if (message.startsWith("INSUFFICIENT_CREDITS:")) {
      const [, required, available] = message.split(":");
      return NextResponse.json({ success: false, message: `This application needs ${required} Credits. You have ${available}.`, code: "INSUFFICIENT_CREDITS", required: Number(required), available: Number(available) }, { status: 409 });
    }
    if (error instanceof RangeError) return NextResponse.json({ success: false, message: "The requirement budget is invalid.", code: "INVALID_BUDGET" }, { status: 400 });
    return NextResponse.json({ success: false, message: "We couldn't submit your application. Please try again.", code: "APPLICATION_FAILED" }, { status: 503 });
  }
}
