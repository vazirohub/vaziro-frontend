import { RequirementStatus } from "@prisma/client";
import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const requirementInput = z.object({
  categoryId: z.string().min(1),
  subcategoryId: z.string().min(1).optional().nullable(),
  title: z.string().trim().min(5).max(120),
  description: z.string().trim().min(20).max(5000),
  budgetPaise: z.number().int().safe().min(1).max(2_000_000_000),
  city: z.string().trim().min(2).max(100),
  postalCode: z.string().trim().max(12).optional(),
  preferredDate: z.string().datetime().optional().nullable(),
  preferredTime: z.string().trim().max(80).optional(),
  frequency: z.string().trim().max(100).optional(),
});

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ success: false, message: "Sign in to view your requirements.", code: "UNAUTHORIZED" }, { status: 401 });
  if (session.user.role !== "CUSTOMER") return NextResponse.json({ success: false, message: "Customer access is required.", code: "FORBIDDEN" }, { status: 403 });
  try {
    const profile = await prisma.customerProfile.findUnique({ where: { userId: session.user.id } });
    if (!profile) return NextResponse.json({ success: true, requirements: [] });
    const requirements = await prisma.requirement.findMany({
      where: { customerId: profile.id },
      include: { category: { select: { name: true } }, subcategory: { select: { name: true } }, _count: { select: { applications: true } }, boosts: { where: { status: "ACTIVE", expiresAt: { gt: new Date() } }, select: { expiresAt: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ success: true, requirements });
  } catch {
    return NextResponse.json({ success: false, message: "We couldn't load your requirements. Refresh and try again." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ success: false, message: "Sign in to post a requirement.", code: "UNAUTHORIZED" }, { status: 401 });
  if (session.user.role !== "CUSTOMER") return NextResponse.json({ success: false, message: "Only customer accounts can post requirements.", code: "FORBIDDEN" }, { status: 403 });

  const parsed = requirementInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ success: false, message: "Check the requirement details and try again.", code: "INVALID_INPUT", errors: parsed.error.flatten().fieldErrors }, { status: 400 });

  try {
    const category = await prisma.category.findFirst({
      where: { id: parsed.data.categoryId, active: true },
      select: { id: true, subcategories: { where: { id: parsed.data.subcategoryId ?? "", active: true }, select: { id: true } } },
    });
    if (!category) return NextResponse.json({ success: false, message: "Choose an active service category.", code: "INVALID_CATEGORY" }, { status: 400 });
    if (parsed.data.subcategoryId && category.subcategories.length === 0) return NextResponse.json({ success: false, message: "Choose a subcategory from this service category.", code: "INVALID_SUBCATEGORY" }, { status: 400 });

    const result = await prisma.$transaction(async (tx) => {
      const customer = await tx.customerProfile.upsert({ where: { userId: session.user.id }, update: {}, create: { userId: session.user.id } });
      const data = parsed.data;
      return tx.requirement.create({
        data: {
          customerId: customer.id,
          categoryId: data.categoryId,
          subcategoryId: data.subcategoryId || null,
          title: data.title,
          description: data.description,
          budgetPaise: data.budgetPaise,
          city: data.city,
          postalCode: data.postalCode || null,
          preferredDate: data.preferredDate ? new Date(data.preferredDate) : null,
          preferredTime: data.preferredTime || null,
          frequency: data.frequency || null,
          status: RequirementStatus.OPEN,
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        },
        include: { category: { select: { name: true } }, subcategory: { select: { name: true } } },
      });
    });
    return NextResponse.json({ success: true, requirement: result }, { status: 201 });
  } catch {
    return NextResponse.json({ success: false, message: "We couldn't publish your requirement. Please try again." }, { status: 503 });
  }
}
