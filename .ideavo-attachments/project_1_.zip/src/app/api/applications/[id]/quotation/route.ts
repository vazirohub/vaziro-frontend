import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const quotationInput = z.object({
  amountPaise: z.number().int().safe().positive().max(2_000_000_000),
  message: z.string().trim().min(20).max(4000),
  expectedTimeline: z.string().trim().max(120).optional(),
  availability: z.string().trim().max(200).optional(),
  terms: z.string().trim().max(2000).optional(),
});

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to submit a quotation." }, { status: 401 });
  if (session.user.role !== "PROFESSIONAL") return NextResponse.json({ message: "Professional access is required." }, { status: 403 });
  const parsed = quotationInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Check your quotation details and try again.", errors: parsed.error.flatten().fieldErrors }, { status: 400 });
  const { id } = await params;
  try {
    const profile = await prisma.professionalProfile.findUnique({ where: { userId: session.user.id } });
    if (!profile) return NextResponse.json({ message: "Complete your professional profile first." }, { status: 409 });
    const application = await prisma.application.findFirst({ where: { id, professionalId: profile.id }, include: { requirement: true } });
    if (!application || application.status === "WITHDRAWN" || application.status === "REJECTED" || application.requirement.status !== "OPEN") return NextResponse.json({ message: "This application can no longer receive a quotation." }, { status: 409 });
    const quotation = await prisma.quotation.upsert({
      where: { applicationId: id },
      create: { applicationId: id, requirementId: application.requirementId, professionalId: profile.id, ...parsed.data, status: "SUBMITTED" },
      update: { ...parsed.data, status: "SUBMITTED" },
    });
    const customer = await prisma.customerProfile.findUnique({ where: { id: application.requirement.customerId }, select: { userId: true } });
    if (customer) await prisma.notification.create({ data: { userId: customer.userId, type: "QUOTATION_RECEIVED", title: "A quotation is ready", body: "A professional sent you a quotation. Compare it in your dashboard." } });
    return NextResponse.json({ success: true, quotation }, { status: 201 });
  } catch {
    return NextResponse.json({ message: "We couldn't submit your quotation. Please try again." }, { status: 503 });
  }
}
