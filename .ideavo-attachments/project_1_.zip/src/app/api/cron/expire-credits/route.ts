import { timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { processExpiredCreditBatches } from "@/lib/credit-expiry";

export async function POST(request: Request) {
  const secret = process.env.CRON_SECRET;
  const provided = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  if (!secret || !provided) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
  const expectedBuffer = Buffer.from(secret);
  const providedBuffer = Buffer.from(provided);
  if (expectedBuffer.length !== providedBuffer.length || !timingSafeEqual(expectedBuffer, providedBuffer)) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
  try {
    const result = await processExpiredCreditBatches();
    return NextResponse.json({ success: true, ...result });
  } catch {
    return NextResponse.json({ message: "Credit expiry processing failed. The job can be safely retried." }, { status: 503 });
  }
}
