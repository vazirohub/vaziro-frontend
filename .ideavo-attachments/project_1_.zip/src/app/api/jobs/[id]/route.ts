import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const input = z.object({ status: z.enum(["COMPLETION_REQUESTED", "COMPLETED"]) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to update this job." }, { status: 401 });
  const parsed = input.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Choose a valid job status." }, { status: 400 });
  const { id } = await params;
  try {
    const job = await prisma.job.findUnique({ where: { id }, include: { requirement: { include: { customer: true } }, professional: true } });
    if (!job) return NextResponse.json({ message: "Job not found." }, { status: 404 });
    if (parsed.data.status === "COMPLETION_REQUESTED") {
      if (session.user.role !== "PROFESSIONAL" || job.professional.userId !== session.user.id) return NextResponse.json({ message: "Only the hired professional can request completion." }, { status: 403 });
      if (job.status !== "ACTIVE") return NextResponse.json({ message: "This job cannot be marked complete now." }, { status: 409 });
      await prisma.job.update({ where: { id }, data: { status: "COMPLETION_REQUESTED" } });
      await prisma.notification.create({ data: { userId: job.requirement.customer.userId, type: "JOB_COMPLETION_REQUESTED", title: "Job completion requested", body: "Confirm that the work is complete from your dashboard." } });
      return NextResponse.json({ success: true, status: "COMPLETION_REQUESTED" });
    }
    if (session.user.role !== "CUSTOMER" || job.requirement.customer.userId !== session.user.id) return NextResponse.json({ message: "Only the customer who posted this requirement can confirm completion." }, { status: 403 });
    if (job.status !== "COMPLETION_REQUESTED") return NextResponse.json({ message: "The professional must request completion first." }, { status: 409 });
    await prisma.$transaction(async (tx) => {
      await tx.job.update({ where: { id }, data: { status: "COMPLETED", completedAt: new Date() } });
      await tx.requirement.update({ where: { id: job.requirementId }, data: { status: "COMPLETED" } });
      await tx.notification.create({ data: { userId: job.professional.userId, type: "JOB_COMPLETED", title: "Job completed", body: "The customer confirmed your job is complete. Reviews are now available." } });
    });
    return NextResponse.json({ success: true, status: "COMPLETED" });
  } catch {
    return NextResponse.json({ message: "We couldn't update this job. Refresh and try again." }, { status: 503 });
  }
}
