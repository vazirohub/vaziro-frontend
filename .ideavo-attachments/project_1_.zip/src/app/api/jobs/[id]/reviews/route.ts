import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const input = z.object({ rating: z.number().int().min(1).max(5), text: z.string().trim().max(2000).optional() });

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to leave a review." }, { status: 401 });
  if (session.user.role !== "CUSTOMER") return NextResponse.json({ message: "Customer access is required." }, { status: 403 });
  const parsed = input.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Choose a rating from 1 to 5 and check your review text." }, { status: 400 });
  const { id } = await params;
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: session.user.id } });
    const job = customer ? await prisma.job.findFirst({ where: { id, requirement: { customerId: customer.id }, status: "COMPLETED" } }) : null;
    if (!job) return NextResponse.json({ message: "Only the customer can review a completed job." }, { status: 404 });
    const review = await prisma.$transaction(async (tx) => {
      const created = await tx.review.create({ data: { jobId: id, customerId: customer!.id, professionalId: job.professionalId, rating: parsed.data.rating, text: parsed.data.text || null } });
      const aggregate = await tx.review.aggregate({ where: { professionalId: job.professionalId }, _avg: { rating: true }, _count: { _all: true } });
      await tx.professionalProfile.update({ where: { id: job.professionalId }, data: { averageRating: aggregate._avg.rating ?? 0, reviewCount: aggregate._count._all } });
      const professional = await tx.professionalProfile.findUnique({ where: { id: job.professionalId }, select: { userId: true } });
      if (professional) await tx.notification.create({ data: { userId: professional.userId, type: "REVIEW_RECEIVED", title: "A customer left a review", body: "A completed customer job now has a review on your profile." } });
      return created;
    });
    return NextResponse.json({ success: true, review }, { status: 201 });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "P2002") return NextResponse.json({ message: "This completed job already has a review." }, { status: 409 });
    return NextResponse.json({ message: "We couldn't save your review. Please try again." }, { status: 503 });
  }
}
