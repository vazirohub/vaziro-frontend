import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      where: { active: true },
      orderBy: { sortOrder: "asc" },
      select: {
        id: true,
        name: true,
        slug: true,
        subcategories: {
          where: { active: true },
          orderBy: { sortOrder: "asc" },
          select: { id: true, name: true, slug: true },
        },
      },
    });
    return NextResponse.json({ success: true, categories });
  } catch {
    return NextResponse.json({ success: false, message: "Categories are temporarily unavailable." }, { status: 503 });
  }
}
