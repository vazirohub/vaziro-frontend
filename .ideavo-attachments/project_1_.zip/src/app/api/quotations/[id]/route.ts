import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

const updateInput = z.object({ status: z.enum(["VIEWED", "SHORTLISTED", "ACCEPTED", "REJECTED"]) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Sign in to update a quotation." }, { status: 401 });
  if (session.user.role !== "CUSTOMER") return NextResponse.json({ message: "Customer access is required." }, { status: 403 });
  const parsed = updateInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Choose a valid quotation action." }, { status: 400 });
  const { id } = await params;
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: session.user.id } });
    if (!customer) return NextResponse.json({ message: "Quotation not found." }, { status: 404 });
    const result = await prisma.$transaction(async (tx) => {
      const quotation = await tx.quotation.findFirst({ where: { id, requirement: { customerId: customer.id } }, include: { requirement: true } });
      if (!quotation) throw new Error("NOT_FOUND");
      if (["ACCEPTED", "REJECTED", "WITHDRAWN", "EXPIRED"].includes(quotation.status)) throw new Error("INVALID_TRANSITION");
      if (parsed.data.status === "ACCEPTED") {
        await tx.$queryRaw(Prisma.sql`SELECT id FROM Requirement WHERE id = ${quotation.requirementId} FOR UPDATE`);
        const requirement = await tx.requirement.findUnique({ where: { id: quotation.requirementId } });
        if (!requirement || requirement.status !== "OPEN") throw new Error("ALREADY_HIRED");
        const updated = await tx.quotation.update({ where: { id }, data: { status: "ACCEPTED" } });
        await tx.application.update({ where: { id: quotation.applicationId }, data: { status: "HIRED" } });
        await tx.application.updateMany({ where: { requirementId: quotation.requirementId, id: { not: quotation.applicationId }, status: { in: ["SUBMITTED", "SHORTLISTED"] } }, data: { status: "REJECTED" } });
        await tx.quotation.updateMany({ where: { requirementId: quotation.requirementId, id: { not: id }, status: { in: ["SUBMITTED", "VIEWED", "SHORTLISTED"] } }, data: { status: "REJECTED" } });
        await tx.requirement.update({ where: { id: quotation.requirementId }, data: { status: "HIRED" } });
        const job = await tx.job.create({ data: { requirementId: quotation.requirementId, quotationId: id, professionalId: quotation.professionalId } });
        const professional = await tx.professionalProfile.findUnique({ where: { id: quotation.professionalId }, select: { userId: true } });
        if (professional) await tx.notification.create({ data: { userId: professional.userId, type: "QUOTATION_ACCEPTED", title: "Your quotation was accepted", body: "The customer accepted your quotation. The job is ready to coordinate." } });
        return { quotation: updated, job };
      }
      const updated = await tx.quotation.update({ where: { id }, data: { status: parsed.data.status } });
      if (parsed.data.status === "REJECTED") await tx.application.update({ where: { id: quotation.applicationId }, data: { status: "REJECTED" } });
      return { quotation: updated };
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    return NextResponse.json({ success: true, ...result });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "NOT_FOUND") return NextResponse.json({ message: "Quotation not found." }, { status: 404 });
    if (message === "INVALID_TRANSITION") return NextResponse.json({ message: "This quotation can no longer be changed." }, { status: 409 });
    if (message === "ALREADY_HIRED") return NextResponse.json({ message: "This requirement is no longer available to hire." }, { status: 409 });
    return NextResponse.json({ message: "We couldn't update this quotation. Please try again." }, { status: 503 });
  }
}
