import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  BriefcaseBusiness,
  ChevronDown,
  CircleHelp,
  Clock3,
  HeartHandshake,
  MapPin,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
} from "lucide-react";
import { AccountActions } from "@/components/account-actions";
import { prisma } from "@/lib/prisma";

const serviceDecoration = [
  { detail: "Thoughtful support at home", icon: "♡", tone: "peach" },
  { detail: "One-to-one learning", icon: "✳", tone: "sage" },
  { detail: "A plan that moves with you", icon: "↗", tone: "blue" },
  { detail: "Professional care, closer", icon: "+", tone: "lilac" },
  { detail: "Postpartum care & newborn specialists", icon: "☼", tone: "yellow" },
  { detail: "Good food, made for you", icon: "⌁", tone: "rose" },
  { detail: "Feel stronger, step by step", icon: "⟡", tone: "mint" },
  { detail: "Mindfulness, flexibility & wellness", icon: "◌", tone: "sand" },
];

const steps = [
  { number: "01", title: "Tell us what you need", body: "Share a few details, your location and budget. Posting a requirement is always free." },
  { number: "02", title: "Compare your options", body: "Get quotations from relevant professionals. Review their experience, availability and approach." },
  { number: "03", title: "Choose with confidence", body: "Talk through the details and hire the person who feels right for you." },
];

export default async function Home() {
  const services = await prisma.category.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" }, take: 8, select: { id: true, name: true, slug: true } }).catch(() => []);
  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Vaziro home">vaziro<span>.</span></a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#services">Explore services <ChevronDown size={14} /></a>
          <a href="#how-it-works">How it works</a>
          <a href="#professionals">For professionals</a>
        </nav>
        <div className="header-actions"><AccountActions /></div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" /> GOOD PEOPLE. GOOD WORK.</div>
          <h1>Find the right help.<br /><em>Feel good about it.</em></h1>
          <p className="hero-intro">Find background-checked home and personal care professionals, compare transparent quotations and choose the right person for your family.</p>
          <form className="search-panel" role="search" action="/professionals" method="get">
            <label className="search-field">
              <Search size={19} aria-hidden="true" />
              <span className="sr-only">What kind of help do you need?</span>
              <input name="category" type="search" placeholder="What kind of help do you need?" />
            </label>
            <span className="search-divider" />
            <label className="location-field">
              <MapPin size={18} aria-hidden="true" />
              <span className="sr-only">Your city or PIN code</span>
              <input name="city" type="text" placeholder="City or PIN code" />
            </label>
            <button className="button button-green search-button" type="submit" aria-label="Find professionals"><ArrowRight size={20} /></button>
          </form>
          <div className="hero-footnote"><ShieldCheck size={16} /> Post free, compare quotations and hire with confidence.</div>
          <div className="hero-proof"><p><strong>Fairness for families. Dignity for professionals.</strong><br /><span>Compare transparent quotations, then choose who to hire.</span></p></div>
        </div>

        <div className="hero-art" aria-label="Illustration of people connecting through Vaziro">
          <div className="art-wash" />
          <div className="orbit orbit-one" /><div className="orbit orbit-two" />
          <div className="art-sun" />
          <div className="art-person person-back"><div className="person-head" /><div className="person-body" /></div>
          <div className="art-person person-front"><div className="person-head" /><div className="person-body" /></div>
          <div className="floating-card card-verified"><span className="mini-check"><BadgeCheck size={16} /></span><span><strong>Clear, comparable quotes</strong><small>Choose the right fit for you</small></span></div>
          <div className="floating-card card-rating"><span className="rating-star"><Star size={15} fill="currentColor" /></span><span><strong>People come first</strong><small>Every match starts with you</small></span></div>
          <div className="art-caption"><span>01 / 03</span><i /> A better kind of marketplace</div>
          <span className="art-sparkle sparkle-one">✳</span><span className="art-sparkle sparkle-two">✦</span>
        </div>
      </section>

      <section className="trust-strip" aria-label="Vaziro values">
        <div><ShieldCheck size={19} /><span>People-first, always</span></div>
        <div><HeartHandshake size={19} /><span>Built around real conversations</span></div>
        <div><CircleHelp size={19} /><span>You choose what feels right</span></div>
        <div><Clock3 size={19} /><span>Free to post a requirement</span></div>
      </section>

      <section className="services-section section-shell" id="services">
        <div className="section-heading">
          <div><div className="eyebrow">VERIFIED HOME & PERSONAL CARE</div><h2>Find the right professional<br className="mobile-break" /> for your family.</h2></div>
          <a className="text-link" href="#get-started">Explore all services <ArrowRight size={17} /></a>
        </div>
        <div className="service-grid">
          {services.map((service, index) => {
            const decoration = serviceDecoration[index % serviceDecoration.length];
            return <a className="service-card" href={`/professionals?category=${encodeURIComponent(service.slug)}`} key={service.id}>
              <span className={`service-icon ${decoration.tone}`} aria-hidden="true">{decoration.icon}</span>
              <span className="service-number">{String(index + 1).padStart(2, "0")}</span>
              <h3>{service.name}</h3>
              <p>Explore local professionals</p>
              <span className="service-arrow"><ArrowUpRight size={17} /></span>
            </a>
          })}
        </div>
      </section>

      <section className="how-section" id="how-it-works">
        <div className="how-inner section-shell">
          <div className="how-intro"><div className="eyebrow">FAIRNESS FOR FAMILIES. DIGNITY FOR PROFESSIONALS.</div><h2>Post once.<br />Compare clearly.</h2><p>Share your budget and requirements once. Qualified professionals respond with transparent quotations, and you decide who to hire.</p><a className="button button-dark" href="/auth/sign-up">Post a requirement <ArrowRight size={17} /></a></div>
          <div className="steps-list">{steps.map((step) => <article className="step" key={step.number}><span className="step-number">{step.number}</span><div><h3>{step.title}</h3><p>{step.body}</p></div><ArrowUpRight className="step-arrow" size={18} /></article>)}</div>
        </div>
      </section>

      <section className="professional-section section-shell" id="professionals">
        <div className="professional-art"><div className="professional-circle"><BriefcaseBusiness size={42} strokeWidth={1.35} /></div><span className="professional-note note-top">Your work matters.</span><span className="professional-note note-bottom">Let the right people find you.</span><span className="prof-star star-a">✳</span><span className="prof-star star-b">✦</span></div>
        <div className="professional-copy"><div className="eyebrow">FOR THE PEOPLE WHO MAKE A DIFFERENCE</div><h2>Good at what you do?<br /><em>There's room for you.</em></h2><p>Meet families looking for your skills, share a quote on your terms and grow your independent practice. Start with a profile that tells your story.</p><ul><li><span>01</span> One profile for your professional work</li><li><span>02</span> Choose requests that fit you</li><li><span>03</span> 0% commission on professional earnings</li></ul><a className="button button-dark" href="/auth/sign-up?accountType=PROFESSIONAL">Join as a professional <ArrowRight size={17} /></a><p className="disclosure">Professional plans provide application Credits and a visibility benefit. We don't guarantee leads, quotations, jobs or placement.</p></div>
      </section>

      <section className="closing-cta" id="get-started"><div className="closing-orb orb-left" /><div className="closing-orb orb-right" /><div className="eyebrow">A GOOD PLACE TO BEGIN</div><h2>Good care starts<br /><em>with the right match.</em></h2><p>Post your requirement for free. Compare transparent quotations from relevant professionals.</p><a className="button button-green" href="/auth/sign-up">Post a requirement <ArrowRight size={18} /></a><span className="closing-free">You decide who to hire. No obligation.</span></section>

      <footer className="site-footer"><a className="wordmark" href="#top">vaziro<span>.</span></a><p>Good people make all the difference.</p><div className="footer-links"><a href="#services">Explore services</a><a href="#professionals">For professionals</a><a href="mailto:hello@vaziro.in">Contact</a></div><small>© 2026 Proanta Technologies Private Limited</small></footer>
    </main>
  );
}
