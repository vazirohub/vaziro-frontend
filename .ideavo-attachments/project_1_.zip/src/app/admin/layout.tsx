import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/session";

export default async function AdminLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const session = await currentSession();
  if (!session) redirect("/auth/sign-in?redirectTo=/admin");
  if (session.user.role !== "ADMIN") redirect("/dashboard");
  return <div className="member-frame"><header className="member-header"><Link className="wordmark" href="/">vaziro<span>.</span></Link><nav aria-label="Admin navigation"><Link href="/admin">Overview</Link><Link href="/admin/catalog">Catalog & plans</Link></nav><span className="member-user">Admin · {session.user.name}</span></header><main className="member-content">{children}</main></div>;
}
