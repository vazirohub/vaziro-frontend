import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const [customers, professionals, openRequirements, applications, quotations, activeJobs, capturedPayments, credits] = await Promise.all([
    prisma.user.count({ where: { role: "CUSTOMER" } }).catch(() => 0),
    prisma.user.count({ where: { role: "PROFESSIONAL" } }).catch(() => 0),
    prisma.requirement.count({ where: { status: "OPEN" } }).catch(() => 0),
    prisma.application.count().catch(() => 0),
    prisma.quotation.count().catch(() => 0),
    prisma.job.count({ where: { status: "ACTIVE" } }).catch(() => 0),
    prisma.payment.aggregate({ where: { status: "CAPTURED" }, _sum: { amountPaise: true }, _count: true }).catch(() => ({ _sum: { amountPaise: 0 }, _count: 0 })),
    prisma.creditBatch.aggregate({ _sum: { remainingPurchasedCredits: true, remainingBonusCredits: true } }).catch(() => ({ _sum: { remainingPurchasedCredits: 0, remainingBonusCredits: 0 } })),
  ]);
  const values = [
    ["Customers", customers], ["Professionals", professionals], ["Open requirements", openRequirements],
    ["Applications", applications], ["Quotations", quotations], ["Active jobs", activeJobs],
    ["Captured payments", capturedPayments._count], ["Credits in batches", (credits._sum.remainingPurchasedCredits ?? 0) + (credits._sum.remainingBonusCredits ?? 0)],
  ] as const;
  return <section><p className="member-kicker">MARKETPLACE OPERATIONS</p><h1 className="admin-heading">Admin overview</h1><p className="form-intro">Operational counts from current marketplace records.</p><div className="admin-stats">{values.map(([label, value]) => <article className="stat-card" key={label}><span>{label}</span><strong>{value.toLocaleString("en-IN")}</strong></article>)}</div><section className="member-section"><div className="member-section-heading"><div><h2>Payment totals</h2><p>Captured marketplace and product payments (gross, before refunds or fees).</p></div></div><div className="admin-revenue">{new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format((capturedPayments._sum.amountPaise ?? 0) / 100)}<span>Captured across {capturedPayments._count} payments</span></div></section></section>;
}
