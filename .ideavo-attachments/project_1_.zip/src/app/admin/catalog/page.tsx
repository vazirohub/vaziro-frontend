import { AdminCatalog } from "@/components/admin-catalog";

export default function AdminCatalogPage() {
  return <section><p className="member-kicker">ADMIN CONFIGURATION</p><h1 className="admin-heading">Catalog & plans</h1><p className="form-intro">Manage service discovery and marketplace products. Changes are recorded in the audit log.</p><AdminCatalog /></section>;
}
