import Link from "next/link";
import { prisma } from "@/lib/prisma";

type Search = { category?: string | string[]; city?: string | string[] };
const text = (value: string | string[] | undefined) => typeof value === "string" ? value.trim() : "";

export default async function ProfessionalsPage({ searchParams }: { searchParams: Promise<Search> }) {
  const params = await searchParams;
  const category = text(params.category);
  const city = text(params.city);
  const professionals = await prisma.professionalProfile.findMany({
    where: {
      ...(city ? { city: { contains: city } } : {}),
      ...(category ? { categories: { some: { category: { active: true, OR: [{ slug: category }, { name: { contains: category } }] } } } } : {}),
      user: { status: "ACTIVE" },
    },
    include: { user: { select: { name: true } }, categories: { include: { category: { select: { name: true } }, subcategory: { select: { name: true } } } } },
    orderBy: [{ verifiedAt: "desc" }, { averageRating: "desc" }, { updatedAt: "desc" }],
    take: 60,
  }).catch(() => []);
  return <main className="directory-page"><header className="directory-header"><Link className="wordmark" href="/">vaziro<span>.</span></Link><nav><Link href="/auth/sign-in">Log in</Link><Link className="button button-dark button-small" href="/auth/sign-up">Get started</Link></nav></header><section className="directory-content"><p className="member-kicker">FIND THE RIGHT FIT</p><h1>Local professionals</h1><p className="form-intro">Explore professionals by service and location. Compare experience and choose who to contact through a requirement.</p><form className="directory-filter" action="/professionals"><label>Service<input name="category" defaultValue={category} placeholder="e.g. Home Tutor" /></label><label>City<input name="city" defaultValue={city} placeholder="City or area" /></label><button className="button button-dark">Search professionals</button></form>{professionals.length === 0 ? <div className="member-empty"><h2>No professionals matched this search</h2><p>Try a different service or location, or post a free requirement for relevant professionals to find you.</p><Link className="button button-dark" href="/auth/sign-up">Create an account</Link></div> : <div className="professional-grid">{professionals.map((profile) => <article className="professional-card" key={profile.id}><div className="professional-avatar">{profile.user.name.slice(0,1).toUpperCase()}</div><div className="professional-profile-title"><h2>{profile.user.name}</h2>{profile.verifiedAt && <span>Verified</span>}</div><p className="professional-headline">{profile.headline || "Independent service professional"}</p><p className="professional-service-list">{profile.categories.map((item) => item.subcategory?.name ?? item.category.name).join(" · ")}</p><div className="professional-card-meta"><span>{profile.city}</span><span>{profile.experienceYears} years experience</span>{profile.reviewCount > 0 && <span>{profile.averageRating.toString()} · {profile.reviewCount} reviews</span>}</div><Link className="text-link" href={`/professionals/${profile.id}`}>View profile <span aria-hidden="true">→</span></Link></article>)}</div>}</section></main>;
}
