import Link from "next/link";
import { AuthForm } from "@/components/auth-form";

export default async function SignUpPage({ searchParams }: PageProps<"/auth/sign-up">) {
  const params = await searchParams;
  const initialAccountType = params.accountType === "PROFESSIONAL" ? "PROFESSIONAL" : "CUSTOMER";
  return <main className="auth-page"><div className="auth-aside"><Link className="wordmark" href="/">vaziro<span>.</span></Link><div><div className="eyebrow">A GOOD PLACE TO BEGIN</div><h1>Good days start<br /><em>with good people.</em></h1><p>Whether you're looking for help or offering your skills, there's a place for you here.</p></div><Link href="/" className="auth-back">← Back to Vaziro</Link></div><section className="auth-panel"><div className="auth-panel-inner"><span className="auth-kicker">JOIN VAZIRO</span><h2>Create your account</h2><p className="auth-subtitle">One account. A more human way to connect.</p><AuthForm mode="sign-up" initialAccountType={initialAccountType} /></div></section></main>;
}
