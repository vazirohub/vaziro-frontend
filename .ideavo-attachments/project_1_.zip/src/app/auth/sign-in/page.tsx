import Link from "next/link";
import { AuthForm } from "@/components/auth-form";

export default async function SignInPage({ searchParams }: PageProps<"/auth/sign-in">) {
  const { redirectTo } = await searchParams;
  const safeRedirect = typeof redirectTo === "string" && redirectTo.startsWith("/") && !redirectTo.startsWith("//") ? redirectTo : "/dashboard";
  return <main className="auth-page"><div className="auth-aside"><Link className="wordmark" href="/">vaziro<span>.</span></Link><div><div className="eyebrow">GOOD PEOPLE. GOOD WORK.</div><h1>Find your way<br /><em>to good help.</em></h1><p>A thoughtful marketplace for the people who make everyday life easier.</p></div><Link href="/" className="auth-back">← Back to Vaziro</Link></div><section className="auth-panel"><div className="auth-panel-inner"><span className="auth-kicker">WELCOME BACK</span><h2>Sign in to Vaziro</h2><p className="auth-subtitle">Pick up where you left off.</p><AuthForm mode="sign-in" redirectTo={safeRedirect} /></div></section></main>;
}
