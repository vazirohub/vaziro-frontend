"use client";

import Link from "next/link";
import { authClient } from "@/lib/auth-client";

export function AccountActions() {
  const { data: session, isPending } = authClient.useSession();
  if (isPending) return <span className="account-skeleton" aria-label="Loading account" />;
  if (!session) return <><Link className="login-link" href="/auth/sign-in">Log in</Link><Link className="button button-dark button-small" href="/auth/sign-up">Get started <span aria-hidden="true">↗</span></Link></>;
  return <div className="signed-in-actions"><Link className="login-link" href="/dashboard">Dashboard</Link><button className="signout-button" onClick={() => void authClient.signOut().then(() => window.location.assign("/"))}>Sign out</button></div>;
}
