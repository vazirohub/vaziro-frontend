"use client";

import { useCallback, useEffect, useState } from "react";

type Quote = {
  id: string;
  amountPaise: number;
  message: string;
  expectedTimeline: string | null;
  availability: string | null;
  status: string;
  createdAt: string;
  professional: {
    headline: string | null;
    experienceYears: number;
    verifiedAt: string | null;
    averageRating: string;
    reviewCount: number;
    user: { name: string; image: string | null };
    categories: Array<{ category: { name: string } }>;
  };
};

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(paise / 100);

export function CustomerQuotations({ requirementId }: { requirementId: string }) {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState("");
  const [notice, setNotice] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const response = await fetch(`/api/requirements/${requirementId}/quotations`, { cache: "no-store" });
      const data = await response.json() as { message?: string; quotations?: Quote[] };
      if (!response.ok) throw new Error(data.message || "We couldn't load quotations.");
      setQuotes(data.quotations ?? []);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "We couldn't load quotations."); }
    finally { setLoading(false); }
  }, [requirementId]);

  useEffect(() => { void refresh(); }, [refresh]);

  async function updateQuote(quoteId: string, status: "ACCEPTED" | "REJECTED") {
    setBusyId(quoteId); setNotice("");
    try {
      const response = await fetch(`/api/quotations/${quoteId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
      const data = await response.json() as { message?: string };
      if (!response.ok) throw new Error(data.message || "We couldn't update this quotation.");
      setNotice(status === "ACCEPTED" ? "Professional hired. Your job is now active." : "Quotation declined.");
      await refresh();
    } catch (cause) { setNotice(cause instanceof Error ? cause.message : "We couldn't update this quotation."); }
    finally { setBusyId(""); }
  }

  if (loading) return <div className="inline-state" role="status">Loading quotations…</div>;
  if (error) return <div className="inline-state inline-error" role="alert"><p>{error}</p><button className="button button-outline" onClick={() => void refresh()}>Try again</button></div>;
  return <>
    <div className="member-section-heading"><div><h2>Compare quotations</h2><p>Review the professional, proposed price and approach before you choose.</p></div><button className="button button-outline" onClick={() => void refresh()} disabled={loading}>Refresh</button></div>
    {notice && <p className="inline-notice" role="status">{notice}</p>}
    {quotes.length === 0 ? <div className="member-empty"><h2>No quotations yet</h2><p>Relevant professionals can send a quotation after reviewing your request. Check back later.</p><button className="button button-outline" onClick={() => void refresh()}>Refresh quotations</button></div> : <div className="quote-list">{quotes.map((quote) => <article className="quote-card" key={quote.id}><div className="quote-person"><div className="quote-avatar">{quote.professional.user.name.slice(0,1).toUpperCase()}</div><div><h3>{quote.professional.user.name}{quote.professional.verifiedAt && <span className="verified-label"> · Verified</span>}</h3><p>{quote.professional.headline ?? quote.professional.categories.map((item) => item.category.name).join(" · ")}</p><small>{quote.professional.experienceYears} years experience · {quote.professional.averageRating} rating · {quote.professional.reviewCount} reviews</small></div></div><div className="quote-amount">{money(quote.amountPaise)}<span>quotation</span></div><p className="quote-message">{quote.message}</p><div className="quote-facts">{quote.expectedTimeline && <span>Timeline: {quote.expectedTimeline}</span>}{quote.availability && <span>Availability: {quote.availability}</span>}</div><div className="quote-actions"><span className={`status-label status-${quote.status.toLowerCase()}`}>{quote.status.toLowerCase()}</span>{["SUBMITTED", "VIEWED", "SHORTLISTED"].includes(quote.status) && <div><button className="button button-outline" onClick={() => void updateQuote(quote.id, "REJECTED")} disabled={Boolean(busyId)}>Decline</button><button className="button button-dark" onClick={() => void updateQuote(quote.id, "ACCEPTED")} disabled={Boolean(busyId)}>{busyId === quote.id ? "Saving…" : "Hire this professional"}</button></div>}</div></article>)}</div>}
  </>;
}
