"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Application = {
  id: string;
  status: string;
  creditsCharged: number;
  createdAt: string;
  requirement: { title: string; city: string; budgetPaise: number; category: { name: string }; subcategory: { name: string } | null };
  quotation: { id: string; status: string; amountPaise: number; message: string } | null;
};

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(paise / 100);

export function ProfessionalApplications() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState("");
  const [notice, setNotice] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/professional/applications", { cache: "no-store" });
      const data = await response.json() as { message?: string; applications?: Application[] };
      if (!response.ok) throw new Error(data.message || "We couldn't load your applications.");
      setApplications(data.applications ?? []);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "We couldn't load your applications."); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  async function submitQuotation(event: FormEvent<HTMLFormElement>, applicationId: string) {
    event.preventDefault(); setNotice(""); setBusyId(applicationId);
    const form = new FormData(event.currentTarget);
    const amount = String(form.get("amount") ?? "").trim();
    const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(amount);
    if (!match) { setBusyId(""); setNotice("Enter a valid quotation amount in rupees."); return; }
    const amountPaise = Number(match[1]) * 100 + Number((match[2] ?? "").padEnd(2, "0"));
    if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) { setBusyId(""); setNotice("Enter a valid positive amount."); return; }
    try {
      const response = await fetch(`/api/applications/${applicationId}/quotation`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ amountPaise, message: form.get("message"), expectedTimeline: form.get("timeline"), availability: form.get("availability") }) });
      const data = await response.json() as { message?: string };
      if (!response.ok) throw new Error(data.message || "We couldn't send your quotation.");
      setNotice("Quotation submitted. The customer can now review your proposal.");
      await refresh();
    } catch (cause) { setNotice(cause instanceof Error ? cause.message : "We couldn't submit your quotation."); }
    finally { setBusyId(""); }
  }

  return <><div className="feed-toolbar"><div><p className="member-kicker">YOUR CUSTOMER CONNECTIONS</p><h1>Applications & quotations</h1><p>Keep every proposal and its status in one place.</p></div><button className="button button-outline" onClick={() => void refresh()} disabled={loading}>{loading ? "Refreshing…" : "Refresh"}</button></div>{notice && <p className="inline-notice" role="status">{notice}</p>}{loading ? <div className="inline-state" role="status">Loading applications…</div> : error ? <div className="inline-state inline-error" role="alert"><p>{error}</p><button className="button button-outline" onClick={() => void refresh()}>Try again</button></div> : applications.length === 0 ? <div className="member-empty"><h2>Your applications will appear here</h2><p>Browse local requests and apply when they match your services.</p><a className="button button-dark" href="/professional/requirements">Find requirements</a></div> : <div className="feed-list">{applications.map((application) => <article className="application-card" key={application.id}><div className="feed-card-head"><div><span className="row-category">{application.requirement.category.name}{application.requirement.subcategory ? ` · ${application.requirement.subcategory.name}` : ""}</span><h2>{application.requirement.title}</h2><p className="application-subtitle">{application.requirement.city} · Customer budget {money(application.requirement.budgetPaise)}</p></div><span className={`status-label status-${application.status.toLowerCase()}`}>{application.status.toLowerCase()}</span></div><div className="application-info"><span>{application.creditsCharged} Credits used · Applied {new Date(application.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</span>{application.quotation && <span>Quotation: {money(application.quotation.amountPaise)} · {application.quotation.status.toLowerCase()}</span>}</div>{!application.quotation && ["SUBMITTED", "SHORTLISTED"].includes(application.status) && <details className="quotation-details"><summary>Prepare a quotation</summary><form className="market-form" onSubmit={(event) => void submitQuotation(event, application.id)}><label>Your quotation (₹)<input name="amount" inputMode="decimal" required placeholder="e.g. 1800" /></label><label>Message to the customer<textarea name="message" required minLength={20} maxLength={4000} rows={4} placeholder="Explain how you would approach this request…" /></label><div className="form-two-col"><label>Expected timeline<input name="timeline" maxLength={120} placeholder="e.g. 4 sessions per month" /></label><label>Your availability<input name="availability" maxLength={200} placeholder="e.g. Weekday evenings" /></label></div><button className="button button-dark" disabled={busyId === application.id}>{busyId === application.id ? "Sending…" : "Submit quotation"}</button></form></details>}</article>)}</div>}</>;
}
