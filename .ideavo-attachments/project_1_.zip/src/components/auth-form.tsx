"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { authClient } from "@/lib/auth-client";

type AuthFormProps = { mode: "sign-in" | "sign-up"; redirectTo?: string; initialAccountType?: "CUSTOMER" | "PROFESSIONAL" };

export function AuthForm({ mode, redirectTo = "/dashboard", initialAccountType = "CUSTOMER" }: AuthFormProps) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const isSignUp = mode === "sign-up";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    try {
      const result = isSignUp
        ? await authClient.signUp.email({
            name: String(form.get("name") ?? "").trim(),
            email,
            password,
            callbackURL: redirectTo,
          })
        : await authClient.signIn.email({ email, password, callbackURL: redirectTo });
      if (result.error) throw new Error(result.error.message || "Check your details and try again.");

      if (isSignUp && form.get("accountType") === "PROFESSIONAL") {
        const activation = await fetch("/api/professional/activate", { method: "POST" });
        if (!activation.ok) throw new Error("Your account was created, but we couldn't finish your professional setup. Sign in and try again.");
      }
      window.location.assign(redirectTo);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "We couldn't sign you in. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="auth-form" onSubmit={submit}>
      {isSignUp && <label>Your name<input name="name" autoComplete="name" required minLength={2} maxLength={80} /></label>}
      <label>Email address<input name="email" type="email" autoComplete="email" inputMode="email" required maxLength={254} /></label>
      <label>Password<input name="password" type="password" autoComplete={isSignUp ? "new-password" : "current-password"} required minLength={8} maxLength={128} /></label>
      {isSignUp && <label>I'm here as<select name="accountType" defaultValue={initialAccountType}><option value="CUSTOMER">Someone looking for a professional</option><option value="PROFESSIONAL">A professional offering services</option></select></label>}
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="button button-dark auth-submit" type="submit" disabled={busy}>{busy ? "Please wait…" : isSignUp ? "Create account" : "Sign in"}</button>
      <p className="auth-switch">{isSignUp ? "Already have an account?" : "New to Vaziro?"} <Link href={isSignUp ? "/auth/sign-in" : "/auth/sign-up"}>{isSignUp ? "Sign in" : "Create an account"}</Link></p>
    </form>
  );
}
