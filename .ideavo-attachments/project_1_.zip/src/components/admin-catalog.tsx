"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Category = { id: string; name: string; slug: string; description: string | null; active: boolean; sortOrder: number; subcategories: Array<{ id: string; name: string; active: boolean }> };
type Plan = { id: string; name: string; pricePaise: number; baseCredits: number; bonusCredits: number; visibility: string; description: string | null; active: boolean; featured: boolean; sortOrder: number };
type Package = { id: string; name: string; pricePaise: number; durationDays: number; priority: number; description: string | null; active: boolean; sortOrder: number };
type Catalog = { categories: Category[]; plans: Plan[]; boostPackages: Package[] };

export function AdminCatalog() {
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/admin/catalog", { cache: "no-store" });
      const data = await response.json() as Catalog & { message?: string };
      if (!response.ok) throw new Error(data.message || "We couldn't load the catalog.");
      setCatalog(data);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "We couldn't load the catalog."); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  async function mutate(key: string, url: string, method: "POST" | "PATCH", body: unknown) {
    setBusy(key); setError(""); setNotice("");
    try {
      const response = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await response.json() as { message?: string };
      if (!response.ok) throw new Error(data.message || "We couldn't save these settings.");
      setNotice("Catalog settings saved."); await refresh(); return true;
    } catch (cause) { setError(cause instanceof Error ? cause.message : "We couldn't save these settings."); return false; }
    finally { setBusy(""); }
  }

  async function create(event: FormEvent<HTMLFormElement>, kind: "category" | "subcategory" | "plan" | "boost", categoryId?: string) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const name = String(form.get("name") ?? "").trim();
    const slug = String(form.get("slug") ?? name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""));
    const body = kind === "category" ? { name, slug, sortOrder: catalog?.categories.length ?? 0, active: true }
      : kind === "subcategory" ? { categoryId, name, slug, sortOrder: 0, active: true }
      : kind === "plan" ? { name, pricePaise: Number(form.get("price")) * 100, baseCredits: Number(form.get("baseCredits")), bonusCredits: Number(form.get("bonusCredits")), visibility: String(form.get("visibility")), description: "Professional Credits and visibility benefit", active: true, featured: false, sortOrder: catalog?.plans.length ?? 0 }
      : { name, pricePaise: Number(form.get("price")) * 100, durationDays: Number(form.get("durationDays")), priority: Number(form.get("priority")), description: String(form.get("description") ?? ""), active: true, sortOrder: catalog?.boostPackages.length ?? 0 };
    const url = kind === "category" ? "/api/admin/categories" : kind === "subcategory" ? "/api/admin/subcategories" : kind === "plan" ? "/api/admin/professional-plans" : "/api/admin/boost-packages";
    const success = await mutate(`create-${kind}`, url, "POST", body);
    if (success) formElement.reset();
  }

  if (loading) return <div className="inline-state" role="status">Loading catalog settings…</div>;
  if (error && !catalog) return <div className="inline-state inline-error" role="alert"><p>{error}</p><button className="button button-outline" onClick={() => void refresh()}>Try again</button></div>;
  if (!catalog) return null;
  return <div className="admin-catalog">{notice && <p className="inline-notice" role="status">{notice}</p>}{error && <p className="form-error" role="alert">{error}</p>}
    <section className="member-section"><div className="member-section-heading"><div><h2>Service categories</h2><p>Categories and specialties are managed in the database.</p></div></div><form className="catalog-create" onSubmit={(event) => void create(event, "category")}><input name="name" required placeholder="New category name" aria-label="New category name"/><input name="slug" placeholder="slug (generated if blank)" aria-label="Category slug"/><button className="button button-dark" disabled={busy === "create-category"}>{busy === "create-category" ? "Saving…" : "Add category"}</button></form><div className="catalog-list">{catalog.categories.map((category) => <details className="catalog-entry" key={category.id}><summary><span>{category.name}<small>{category.slug} · {category.subcategories.length} specialties</small></span><span className={category.active ? "catalog-active" : "catalog-inactive"}>{category.active ? "Active" : "Disabled"}</span></summary><div className="catalog-entry-body"><div className="catalog-subcategories">{category.subcategories.map((sub) => <span key={sub.id}>{sub.name}{!sub.active ? " · Disabled" : ""}</span>)}</div><form className="catalog-create" onSubmit={(event) => void create(event, "subcategory", category.id)}><input name="name" required placeholder={`Add a ${category.name} specialty`} aria-label={`New specialty for ${category.name}`}/><button className="button button-outline" disabled={busy === `create-subcategory`}>{busy === "create-subcategory" ? "Saving…" : "Add specialty"}</button></form><div className="catalog-actions"><button className="button button-outline" disabled={Boolean(busy)} onClick={() => void mutate(category.id, `/api/admin/categories/${category.id}`, "PATCH", { name: category.name, slug: category.slug, description: category.description, active: !category.active, sortOrder: category.sortOrder })}>{category.active ? "Disable category" : "Enable category"}</button></div></div></details>)}</div></section>
    <section className="member-section"><div className="member-section-heading"><div><h2>Professional Plans</h2><p>One product: application Credits plus a visibility benefit.</p></div></div><form className="catalog-create catalog-plan-create" onSubmit={(event) => void create(event, "plan")}><input name="name" required placeholder="Plan name" aria-label="Plan name"/><input name="price" type="number" min="1" required placeholder="Price in rupees" aria-label="Plan price in rupees"/><input name="baseCredits" type="number" min="0" required placeholder="Base Credits" aria-label="Base Credits"/><input name="bonusCredits" type="number" min="0" required placeholder="Bonus Credits" aria-label="Bonus Credits"/><select name="visibility" aria-label="Visibility tier"><option value="STANDARD">Standard</option><option value="ENHANCED">Enhanced</option><option value="HIGH">Higher</option><option value="HIGH_PRIORITY">High priority</option><option value="HIGHEST">Highest</option></select><button className="button button-dark" disabled={busy === "create-plan"}>{busy === "create-plan" ? "Saving…" : "Add plan"}</button></form><div className="catalog-list">{catalog.plans.map((plan) => <article className="catalog-entry catalog-row" key={plan.id}><span><strong>{plan.name}</strong><small>₹{(plan.pricePaise / 100).toLocaleString("en-IN")} · {plan.baseCredits} base + {plan.bonusCredits} bonus · {plan.visibility.toLowerCase().replaceAll("_", " ")}</small></span><button className="button button-outline" disabled={Boolean(busy)} onClick={() => void mutate(plan.id, `/api/admin/professional-plans/${plan.id}`, "PATCH", { name: plan.name, pricePaise: plan.pricePaise, baseCredits: plan.baseCredits, bonusCredits: plan.bonusCredits, visibility: plan.visibility, description: plan.description ?? "", active: !plan.active, featured: plan.featured, sortOrder: plan.sortOrder })}>{plan.active ? "Disable" : "Enable"}</button></article>)}</div></section>
    <section className="member-section"><div className="member-section-heading"><div><h2>Customer requirement boosts</h2><p>Optional visibility packages for an individual customer requirement.</p></div></div><form className="catalog-create" onSubmit={(event) => void create(event, "boost")}><input name="name" required placeholder="Package name" aria-label="Boost package name"/><input name="price" type="number" min="1" required placeholder="Price in rupees" aria-label="Boost price in rupees"/><input name="durationDays" type="number" min="1" required placeholder="Duration in days" aria-label="Boost duration"/><input name="priority" type="number" min="0" required placeholder="Priority" aria-label="Boost priority"/><button className="button button-dark" disabled={busy === "create-boost"}>{busy === "create-boost" ? "Saving…" : "Add package"}</button></form><div className="catalog-list">{catalog.boostPackages.map((pack) => <article className="catalog-entry catalog-row" key={pack.id}><span><strong>{pack.name}</strong><small>₹{(pack.pricePaise / 100).toLocaleString("en-IN")} · {pack.durationDays} days · priority {pack.priority}</small></span><button className="button button-outline" disabled={Boolean(busy)} onClick={() => void mutate(pack.id, `/api/admin/boost-packages/${pack.id}`, "PATCH", { name: pack.name, pricePaise: pack.pricePaise, durationDays: pack.durationDays, priority: pack.priority, description: pack.description ?? "", active: !pack.active, sortOrder: pack.sortOrder })}>{pack.active ? "Disable" : "Enable"}</button></article>)}</div></section>
  </div>;
}
