"use client";

import { FormEvent, useEffect, useState } from "react";

type Category = { id: string; name: string; subcategories: Array<{ id: string; name: string }> };

function toPaise(value: string) {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(value.trim());
  if (!match) return null;
  const paise = Number(match[1]) * 100 + Number((match[2] ?? "").padEnd(2, "0"));
  return Number.isSafeInteger(paise) && paise > 0 ? paise : null;
}

export function RequirementForm() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  async function loadCategories() {
    setLoading(true);
    setLoadError("");
    try {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Service categories are unavailable right now.");
      const data = await response.json() as { categories?: Category[] };
      setCategories(data.categories ?? []);
      setCategoryId((current) => current || data.categories?.[0]?.id || "");
    } catch (cause) {
      setLoadError(cause instanceof Error ? cause.message : "We couldn't load services.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void loadCategories(); }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const form = new FormData(event.currentTarget);
    const budgetPaise = toPaise(String(form.get("budget") ?? ""));
    if (!budgetPaise) { setError("Enter a valid budget in rupees, such as 1500 or 1499.50."); return; }
    setBusy(true);
    try {
      const preferredDate = String(form.get("preferredDate") ?? "");
      const response = await fetch("/api/requirements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          categoryId,
          subcategoryId: String(form.get("subcategoryId") ?? "") || null,
          title: form.get("title"),
          description: form.get("description"),
          budgetPaise,
          city: form.get("city"),
          postalCode: form.get("postalCode"),
          preferredDate: preferredDate ? new Date(`${preferredDate}T00:00:00+05:30`).toISOString() : null,
          preferredTime: form.get("preferredTime"),
          frequency: form.get("frequency"),
        }),
      });
      const data = await response.json() as { message?: string };
      if (!response.ok) throw new Error(data.message || "We couldn't publish your requirement.");
      setSuccess(true);
      window.location.assign("/dashboard");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "We couldn't publish your requirement. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="inline-state" role="status">Loading service categories…</div>;
  if (loadError) return <div className="inline-state inline-error" role="alert"><p>{loadError}</p><button className="button button-dark" onClick={() => void loadCategories()}>Try again</button></div>;
  if (!categories.length) return <div className="inline-state"><p>No service categories are available yet.</p></div>;

  const selected = categories.find((category) => category.id === categoryId);
  return <form className="market-form" onSubmit={submit}>
    <div className="form-two-col"><label>Service category<select name="categoryId" value={categoryId} onChange={(event) => setCategoryId(event.target.value)} required>{categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Specialty (optional)<select name="subcategoryId" defaultValue=""><option value="">Choose a specialty</option>{selected?.subcategories.map((sub) => <option key={sub.id} value={sub.id}>{sub.name}</option>)}</select></label></div>
    <label>What do you need?<input name="title" required minLength={5} maxLength={120} placeholder="e.g. Weekly maths tutoring for Class 8" /></label>
    <label>Share a few details<textarea name="description" required minLength={20} maxLength={5000} rows={5} placeholder="Tell professionals what would make this a good fit…" /></label>
    <div className="form-two-col"><label>Your budget (₹)<input name="budget" inputMode="decimal" type="text" required placeholder="e.g. 1500" aria-describedby="budget-help" /><small id="budget-help">Enter any amount in rupees. Posting is free.</small></label><label>City<input name="city" autoComplete="address-level2" required minLength={2} maxLength={100} placeholder="e.g. Pune" /></label></div>
    <div className="form-three-col"><label>PIN code (optional)<input name="postalCode" inputMode="numeric" autoComplete="postal-code" maxLength={12} /></label><label>Preferred date (optional)<input name="preferredDate" type="date" /></label><label>Preferred time (optional)<input name="preferredTime" placeholder="e.g. Weekday evenings" maxLength={80} /></label></div>
    <label>How often? (optional)<select name="frequency" defaultValue=""><option value="">Choose frequency</option><option>One time</option><option>Daily</option><option>Weekly</option><option>Monthly</option><option>Ongoing</option></select></label>
    {error && <p className="form-error" role="alert">{error}</p>}
    {success && <p className="form-success" role="status">Your requirement is live. Taking you to your dashboard…</p>}
    <div className="form-submit-row"><p>Free to post. You'll choose who to hire after comparing quotations.</p><button className="button button-dark" type="submit" disabled={busy}>{busy ? "Publishing…" : "Publish requirement"}</button></div>
  </form>;
}
