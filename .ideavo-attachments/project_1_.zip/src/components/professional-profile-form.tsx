"use client";

import { FormEvent, useEffect, useState } from "react";

type Category = { id: string; name: string };
type InitialProfile = { headline?: string | null; description?: string | null; experienceYears?: number; city?: string | null; skills?: unknown; categories?: Array<{ categoryId: string }> };

export function ProfessionalProfileForm() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [initial, setInitial] = useState<InitialProfile | null>(null);
  const [skills, setSkills] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/professional/profile", { cache: "no-store" });
      const data = await response.json() as { message?: string; profile?: InitialProfile; categories?: Category[] };
      if (!response.ok) throw new Error(data.message || "We couldn't load your profile.");
      const profile = data.profile ?? null;
      setInitial(profile);
      setCategories(data.categories ?? []);
      setSelected(profile?.categories?.map((item) => item.categoryId) ?? []);
      setSkills(Array.isArray(profile?.skills) ? profile.skills.join(", ") : "");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "We couldn't load your profile."); }
    finally { setLoading(false); }
  }

  useEffect(() => { void load(); }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(""); setSaved(false); setSaving(true);
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/professional/profile", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ headline: form.get("headline"), description: form.get("description"), experienceYears: Number(form.get("experienceYears")), city: form.get("city"), skills: skills.split(",").map((skill) => skill.trim()).filter(Boolean), categoryIds: selected }),
      });
      const data = await response.json() as { message?: string };
      if (!response.ok) throw new Error(data.message || "We couldn't save your profile.");
      setSaved(true);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "We couldn't save your profile. Please try again."); }
    finally { setSaving(false); }
  }

  if (loading) return <div className="inline-state" role="status">Loading your profile…</div>;
  if (error && !categories.length) return <div className="inline-state inline-error" role="alert"><p>{error}</p><button className="button button-outline" onClick={() => void load()}>Try again</button></div>;
  return <form className="market-form" onSubmit={submit}>
    <label>Professional headline<input name="headline" defaultValue={initial?.headline ?? ""} required minLength={5} maxLength={120} placeholder="e.g. Patient home tutor for primary and middle school" /></label>
    <label>About your work<textarea name="description" defaultValue={initial?.description ?? ""} required minLength={40} maxLength={3000} rows={5} placeholder="Share your approach, experience and what customers can expect…" /></label>
    <div className="form-two-col"><label>Years of experience<input name="experienceYears" defaultValue={initial?.experienceYears ?? 0} type="number" min={0} max={70} required /></label><label>Primary service city<input name="city" defaultValue={initial?.city ?? ""} required minLength={2} maxLength={100} placeholder="e.g. Bengaluru" /></label></div>
    <label>Skills, separated by commas<input value={skills} onChange={(event) => setSkills(event.target.value)} placeholder="e.g. Early learning, exam preparation" /></label>
    <fieldset className="category-picker"><legend>Services you offer</legend><p>Select every service category that fits your work.</p>{categories.map((category) => <label key={category.id}><input type="checkbox" checked={selected.includes(category.id)} onChange={(event) => setSelected((current) => event.target.checked ? [...current, category.id] : current.filter((id) => id !== category.id))} />{category.name}</label>)}</fieldset>
    {error && <p className="form-error" role="alert">{error}</p>}{saved && <p className="form-success" role="status">Your professional profile is saved.</p>}
    <div className="form-submit-row"><p>Your profile helps match you with relevant requests in your area.</p><button className="button button-dark" disabled={saving || selected.length === 0}>{saving ? "Saving…" : "Save profile"}</button></div>
  </form>;
}
