"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { creditsForBudgetPaise } from "@/lib/credits";

type Requirement = {
  id: string;
  title: string;
  description: string;
  city: string;
  budgetPaise: number;
  createdAt: string;
  preferredDate: string | null;
  preferredTime: string | null;
  category: { name: string };
  subcategory: { name: string } | null;
  boosts: Array<{ id: string }>;
};

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: paise % 100 ? 2 : 0 }).format(paise / 100);

export function RequirementFeed() {
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState<Requirement | null>(null);
  const [busyId, setBusyId] = useState("");
  const [notice, setNotice] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/professional/requirements", { cache: "no-store" });
      const data = await response.json() as { success?: boolean; message?: string; requirements?: Requirement[]; needsProfile?: boolean };
      if (!response.ok) throw new Error(data.message || "We couldn't load requirements.");
      if (data.needsProfile) throw new Error("Add your service categories and city to see relevant requirements.");
      setRequirements(data.requirements ?? []);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "We couldn't load requirements.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  async function apply() {
    if (!selected) return;
    setBusyId(selected.id);
    setNotice("");
    try {
      const response = await fetch(`/api/requirements/${selected.id}/apply`, { method: "POST" });
      const data = await response.json() as { message?: string; code?: string; creditsCharged?: number };
      if (!response.ok) throw new Error(data.message || "We couldn't submit your application.");
      setRequirements((current) => current.filter((item) => item.id !== selected.id));
      setSelected(null);
      setNotice(`${data.creditsCharged ?? creditsForBudgetPaise(selected.budgetPaise)} Credits used. Your application was submitted.`);
    } catch (cause) {
      setNotice(cause instanceof Error ? cause.message : "We couldn't submit your application. Please try again.");
    } finally {
      setBusyId("");
    }
  }

  return <>
    <div className="feed-toolbar"><div><p className="member-kicker">MATCHED TO YOUR SERVICES</p><h1>Find requirements</h1><p>Apply only when the request, location and timing feel right.</p></div><button className="button button-outline" onClick={() => void refresh()} disabled={loading}>{loading ? "Refreshing…" : "Refresh"}</button></div>
    {notice && <p className="inline-notice" role="status">{notice}{notice.includes("need") || notice.includes("have") ? <> <Link href="/professional/plans">Explore plans</Link></> : null}</p>}
    {loading ? <div className="inline-state" role="status">Finding relevant requests…</div> : error ? <div className="inline-state inline-error" role="alert"><p>{error}</p><Link className="button button-dark" href="/professional/profile">Set up your profile</Link><button className="button button-outline" onClick={() => void refresh()}>Try again</button></div> : requirements.length === 0 ? <div className="member-empty"><span className="empty-mark">⌕</span><h2>No matching requests right now</h2><p>We'll show open requirements that match your selected categories and service area here.</p><button className="button button-outline" onClick={() => void refresh()}>Refresh requirements</button></div> : <div className="feed-list">{requirements.map((item) => {
      const cost = creditsForBudgetPaise(item.budgetPaise);
      return <article className="feed-card" key={item.id}><div className="feed-card-head"><div><span className="row-category">{item.category.name}{item.subcategory ? ` · ${item.subcategory.name}` : ""}</span><h2>{item.title}</h2></div>{item.boosts.length > 0 && <span className="boost-label">Boosted</span>}</div><p className="feed-description">{item.description}</p><div className="feed-facts"><span>{item.city}</span><span>{money(item.budgetPaise)} budget</span><span>Posted {new Date(item.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</span>{item.preferredDate && <span>{new Date(item.preferredDate).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}{item.preferredTime ? ` · ${item.preferredTime}` : ""}</span>}</div><div className="feed-card-footer"><p><strong>{cost} Credits</strong> to apply</p><button className="button button-dark" onClick={() => setSelected(item)}>Review application</button></div></article>;
    })}</div>}
    {selected && <div className="dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busyId) setSelected(null); }}><section className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="apply-title"><button className="dialog-close" aria-label="Close confirmation" onClick={() => setSelected(null)}>×</button><p className="member-kicker">APPLICATION COST</p><h2 id="apply-title">Apply to this requirement?</h2><p className="dialog-summary">{selected.title}</p><dl><div><dt>Customer budget</dt><dd>{money(selected.budgetPaise)}</dd></div><div><dt>Application cost</dt><dd>{creditsForBudgetPaise(selected.budgetPaise)} Credits</dd></div></dl><p className="dialog-explainer">We'll recalculate the Credit cost from the current budget and deduct it only if your application succeeds.</p><div className="dialog-actions"><button className="button button-outline" onClick={() => setSelected(null)} disabled={Boolean(busyId)}>Go back</button><button className="button button-dark" onClick={() => void apply()} disabled={Boolean(busyId)}>{busyId ? "Applying…" : "Confirm & apply"}</button></div></section></div>}
  </>;
}
