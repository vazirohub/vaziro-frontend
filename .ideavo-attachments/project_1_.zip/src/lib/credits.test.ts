import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { creditsForBudgetPaise, refundableAmountPaise } from "./credits";

describe("professional application credits", () => {
  const examples: Array<[number, number]> = [
    [50, 1], [99, 1], [100, 1], [149, 2], [499, 5], [999, 10],
    [1499, 15], [2350, 24], [2999, 30], [5000, 50], [12345, 124], [50000, 500],
  ];
  for (const [rupees, credits] of examples) {
    it(`charges ${rupees} INR as ${credits} Credits`, () => {
      assert.equal(creditsForBudgetPaise(rupees * 100), credits);
    });
  }

  for (const amount of [0, -1, 0.5, Number.MAX_SAFE_INTEGER + 1]) {
    it(`rejects invalid budget ${amount}`, () => {
      assert.throws(() => creditsForBudgetPaise(amount), RangeError);
    });
  }

  it("calculates refunds only from remaining purchased Credits", () => {
    assert.equal(refundableAmountPaise(60), 60_000);
    assert.equal(refundableAmountPaise(0), 0);
  });
});
