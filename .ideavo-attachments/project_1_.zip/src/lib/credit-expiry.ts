import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";

export async function processExpiredCreditBatches(now = new Date()) {
  return prisma.$transaction(async (tx) => {
    const expired = await tx.creditBatch.findMany({
      where: { status: "ACTIVE", expiresAt: { lte: now } },
      orderBy: [{ professionalId: "asc" }, { expiresAt: "asc" }, { grantedAt: "asc" }],
    });
    let processed = 0;
    let refundable = 0;

    for (const batch of expired) {
      await tx.$queryRaw(Prisma.sql`SELECT id FROM CreditBatch WHERE id = ${batch.id} FOR UPDATE`);
      const current = await tx.creditBatch.findUnique({ where: { id: batch.id } });
      if (!current || current.status !== "ACTIVE" || !current.expiresAt || current.expiresAt > now) continue;
      const expiring = current.remainingPurchasedCredits + current.remainingBonusCredits;
      const hasRefundableBase = current.remainingPurchasedCredits > 0;
      const nextStatus = hasRefundableBase ? "ELIGIBLE" : "EXPIRED_NON_REFUNDABLE";
      const before = await tx.creditBatch.aggregate({
        where: { professionalId: current.professionalId, status: "ACTIVE" },
        _sum: { remainingPurchasedCredits: true, remainingBonusCredits: true },
      });
      const balanceBefore = (before._sum.remainingPurchasedCredits ?? 0) + (before._sum.remainingBonusCredits ?? 0);
      const updated = await tx.creditBatch.updateMany({
        where: { id: current.id, status: "ACTIVE" },
        data: {
          status: nextStatus,
          remainingBonusCredits: 0,
          ...(hasRefundableBase ? {} : { remainingPurchasedCredits: 0 }),
        },
      });
      if (updated.count !== 1) continue;
      if (expiring > 0) {
        await tx.creditLedger.create({
          data: {
            professionalId: current.professionalId,
            batchId: current.id,
            type: "EXPIRATION",
            amount: -expiring,
            balanceBefore,
            balanceAfter: Math.max(0, balanceBefore - expiring),
            referenceId: current.id,
            reason: hasRefundableBase ? "Expired Credits; unused purchased Credits are eligible for refund" : "Expired non-refundable Credits",
          },
        });
      }
      processed += 1;
      if (hasRefundableBase) refundable += current.remainingPurchasedCredits;
    }

    return { processed, refundableCredits: refundable };
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}
