import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { prisma } from "@/lib/prisma";

export const auth = betterAuth({
  database: prismaAdapter(prisma, { provider: "mysql" }),
  emailAndPassword: { enabled: true },
  user: {
    additionalFields: {
      role: {
        type: "string",
        required: false,
        defaultValue: "CUSTOMER",
        input: false,
      },
      status: {
        type: "string",
        required: false,
        defaultValue: "ACTIVE",
        input: false,
      },
    },
  },
  baseURL: process.env.BETTER_AUTH_URL || "http://localhost:4000",
  trustedOrigins: ["https://vaziro.in", "http://localhost:4000"],
  advanced: {
    defaultCookieAttributes:
      process.env.NODE_ENV === "production"
        ? undefined
        : { sameSite: "none", secure: true },
  },
  rateLimit: { enabled: true },
});
