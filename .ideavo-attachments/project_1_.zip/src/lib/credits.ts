export function creditsForBudgetPaise(budgetPaise: number): number {
  if (!Number.isSafeInteger(budgetPaise) || budgetPaise <= 0) {
    throw new RangeError("Budget must be a positive whole number of paise");
  }
  return Math.max(1, Math.ceil(budgetPaise / 10_000));
}

export function refundableAmountPaise(remainingPurchasedCredits: number): number {
  if (!Number.isSafeInteger(remainingPurchasedCredits) || remainingPurchasedCredits < 0) {
    throw new RangeError("Remaining purchased Credits must be a non-negative integer");
  }
  return remainingPurchasedCredits * 1_000;
}
